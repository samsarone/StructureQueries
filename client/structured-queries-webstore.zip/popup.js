"use strict";
(() => {
  // src/popup.ts
  var SERVER_HTTP_ORIGIN = "https://structurequeries.samsar.one";
  var SERVER_WS_URL = "wss://structurequeries.samsar.one/ws/plugin";
  var ANALYZED_PAGES_STORAGE_KEY = "structuredqueries.analyzedPages";
  var REGISTRATION_STORAGE_KEY = "structuredqueries.registration";
  var PREPARE_PAGE_SETTINGS_STORAGE_KEY = "structuredqueries.preparePageSettings";
  var PREPARE_PAGE_REQUESTS_STORAGE_KEY = "structuredqueries.preparePageRequests";
  var LEGACY_ANALYZED_PAGES_STORAGE_KEY = "telepathy.analyzedPages";
  var LEGACY_REGISTRATION_STORAGE_KEY = "telepathy.registration";
  var STARTER_CREDITS = 50;
  var LOW_CREDIT_WARNING_THRESHOLD = 100;
  var MIN_VOICE_CONVERSATION_CREDITS = 10;
  var RECHARGE_CREDITS_THRESHOLD = MIN_VOICE_CONVERSATION_CREDITS;
  var RECHARGE_CREDITS_MESSAGE = "Recharge credits";
  var CONVERSATION_IDLE_TIMEOUT_MS = 10 * 60 * 1e3;
  var NOTIFICATION_DURATION_MS = 6e3;
  var DEFAULT_PREPARE_PAGE_MAX_CREDITS = 20;
  var MIN_PREPARE_PAGE_MAX_CREDITS = 1;
  var MAX_PREPARE_PAGE_MAX_CREDITS = 100;
  var DEFAULT_CACHING_TTL_SECONDS = 60 * 60;
  var ONE_DAY_CACHING_TTL_SECONDS = 24 * 60 * 60;
  var EMBEDDING_TEMPLATE_EXPIRED_CODE = "EMBEDDING_TEMPLATE_EXPIRED";
  var EXPIRED_PAGE_CACHE_MESSAGE = "This page cache expired. Prepare the page again.";
  var creditCountFormatter = new Intl.NumberFormat();
  var accountButton = document.querySelector("#account-button");
  var accountNameNode = document.querySelector("#account-name");
  var accountHintNode = document.querySelector("#account-hint");
  var accountEmailNode = document.querySelector("#account-email");
  var accountUsernameNode = document.querySelector("#account-username");
  var accountUserIdNode = document.querySelector("#account-user-id");
  var overlayCloseButtons = document.querySelectorAll("[data-overlay-close-button]");
  var headerCreditsNode = document.querySelector("#header-credits");
  var analysisPillNode = document.querySelector("#analysis-pill");
  var pageTitleNode = document.querySelector("#page-title");
  var pageUrlNode = document.querySelector("#page-url");
  var pageLanguageNode = document.querySelector("#page-language");
  var registrationOverlayNode = document.querySelector("#registration-overlay");
  var registrationFormNode = document.querySelector("#registration-form");
  var registrationEyebrowNode = document.querySelector("#registration-eyebrow");
  var registrationTitleNode = document.querySelector("#registration-title");
  var registrationSubtitleNode = document.querySelector("#registration-subtitle");
  var registrationStatusNode = document.querySelector("#registration-status");
  var registrationCloseButton = document.querySelector("#registration-close-button");
  var registrationSubmitButton = document.querySelector("#registration-submit-button");
  var registrationDisplayNameNode = document.querySelector("#registration-display-name");
  var registrationEmailNode = document.querySelector("#registration-email");
  var registrationUsernameNode = document.querySelector("#registration-username");
  var authHelperCopyNode = document.querySelector(".auth-helper-copy");
  var settingsCreditsRemainingNode = document.querySelector("#settings-credits-remaining");
  var settingsCreditsCaptionNode = document.querySelector("#settings-credits-caption");
  var cachingTtlSelect = document.querySelector("#caching-ttl-select");
  var prepareMaxCreditsInput = document.querySelector("#prepare-max-credits-input");
  var samsarAuthButton = document.querySelector("#samsar-auth-button");
  var samsarLoginButton = document.querySelector("#samsar-login-button");
  var analysisStatusNode = document.querySelector("#analysis-status");
  var conversationLogNode = document.querySelector("#conversation-log");
  var overlayShellNode = document.querySelector(".overlay-shell");
  var analyzeButton = document.querySelector("#analyze-button");
  var analyzeButtonLabel = document.querySelector("#analyze-button-label");
  var analyzeButtonIcon = document.querySelector("#analyze-button-icon");
  var buttonRowNode = document.querySelector("#button-row");
  var surfaceStatusNode = document.querySelector("#surface-status");
  var creditWarningNode = document.querySelector("#credit-warning");
  var creditWarningMessageNode = document.querySelector("#credit-warning-message");
  var creditWarningButton = document.querySelector("#credit-warning-button");
  var creditWarningDismissButton = document.querySelector("#credit-warning-dismiss-button");
  var notificationNode = document.querySelector("#notification-banner");
  var notificationMessageNode = document.querySelector("#notification-message");
  var notificationActionButton = document.querySelector("#notification-action");
  var voiceToggleButton = document.querySelector("#voice-toggle-button");
  var voiceToggleButtonLabel = document.querySelector("#voice-toggle-button-label");
  var voiceToggleButtonIcon = document.querySelector("#voice-toggle-button-icon");
  var voiceSelect = document.querySelector("#voice-select");
  var voicePreviewButton = document.querySelector("#voice-preview-button");
  var voiceWarningNode = document.querySelector("#voice-warning");
  var languageSelect = document.querySelector("#language-select");
  var interactionModeVoiceButton = document.querySelector("#interaction-mode-voice");
  var interactionModeTextButton = document.querySelector("#interaction-mode-text");
  var voiceModeShellNode = document.querySelector("#voice-mode-shell");
  var textModeShellNode = document.querySelector("#text-mode-shell");
  var textAnalyzeButton = document.querySelector("#text-analyze-button");
  var textAnalyzeButtonLabel = document.querySelector("#text-analyze-button-label");
  var textAnalyzeButtonIcon = document.querySelector("#text-analyze-button-icon");
  var textChatStatusNode = document.querySelector("#text-chat-status");
  var textChatThreadNode = document.querySelector("#text-chat-thread");
  var textChatFormNode = document.querySelector("#text-chat-form");
  var textChatInputNode = document.querySelector("#text-chat-input");
  var textChatSubmitButton = document.querySelector("#text-chat-submit");
  var textChatSubmitButtonLabel = document.querySelector("#text-chat-submit-label");
  var textChatSubmitButtonIcon = document.querySelector("#text-chat-submit-icon");
  var state = {
    currentUser: null,
    registrationRequired: true,
    registrationSubmitting: false,
    samsarAuthSubmitting: false,
    loginLinkSubmitting: false,
    accountEditorOpen: false,
    serverOnline: false,
    indexChecked: false,
    analysisReady: false,
    isAnalyzing: false,
    isInitializing: true,
    websocketState: "disconnected",
    websocketPhase: "idle",
    websocketDetail: "Idle",
    interactionMode: "voice",
    voices: [],
    voiceWarning: void 0,
    creditIssueMessage: void 0,
    creditBannerDismissed: false,
    preferredVoiceId: void 0,
    preferredVoiceName: void 0,
    voicePreviewState: "idle",
    voicePreviewVoiceId: void 0,
    notificationMessage: void 0,
    notificationAction: void 0,
    pageCacheExpired: false,
    conversationActive: false,
    pendingAssistantLanguage: void 0,
    assistantSpeaking: false,
    recording: false,
    textDraft: "",
    textMessages: [],
    textSubmitting: false,
    pendingTextPrompt: void 0,
    pendingTextMessageId: void 0,
    cachingTtlSeconds: DEFAULT_CACHING_TTL_SECONDS,
    maxPrepareCredits: DEFAULT_PREPARE_PAGE_MAX_CREDITS
  };
  var activeSocket;
  var activeSocketPromise;
  var activeAssistantAudio;
  var activeAssistantAudioObjectUrl;
  var activeVoicePreviewAudio;
  var activeAnalyzeRequestController;
  var activeTextRequestController;
  var resumeConversationTimer;
  var conversationIdleTimer;
  var notificationTimer;
  var prepareStatusPollTimer;
  var assistantAudioReceivedForTurn = false;
  var creditsRefreshPending = false;
  var creditsRefreshInFlight = false;
  var voicesLoaded = false;
  var voicesLoadPromise;
  var BUTTON_ICONS = {
    mic: `
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M10 3.2a2.7 2.7 0 0 1 2.7 2.7v3.8a2.7 2.7 0 1 1-5.4 0V5.9A2.7 2.7 0 0 1 10 3.2Z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M5.7 8.8v.7A4.3 4.3 0 0 0 10 13.8a4.3 4.3 0 0 0 4.3-4.3v-.7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <path d="M10 13.8v2.9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <path d="M7.6 16.7h4.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
    </svg>
  `,
    stop: `
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <rect x="5.2" y="5.2" width="9.6" height="9.6" rx="2.1" stroke="currentColor" stroke-width="1.6"/>
    </svg>
  `,
    scan: `
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M7.4 3.8H5.6A1.8 1.8 0 0 0 3.8 5.6v1.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <path d="M12.6 3.8h1.8a1.8 1.8 0 0 1 1.8 1.8v1.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <path d="M16.2 12.6v1.8a1.8 1.8 0 0 1-1.8 1.8h-1.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <path d="M3.8 12.6v1.8a1.8 1.8 0 0 0 1.8 1.8h1.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <path d="M7.6 10h4.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <path d="M10 7.6v4.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
    </svg>
  `,
    redo: `
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M15.1 7.2A5.6 5.6 0 0 0 6 5.3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <path d="M15 3.9v3.8h-3.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M4.9 12.8A5.6 5.6 0 0 0 14 14.7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
      <path d="M5 16.1v-3.8h3.8" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  `,
    send: `
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M3.8 10 15.7 4.4c.7-.3 1.4.4 1.1 1.1L11.2 17.4c-.3.7-1.3.7-1.6 0L7.8 12l-4-1.8c-.7-.3-.7-1.3 0-1.6Z" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="m7.8 12 4.6-4.6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
    </svg>
  `,
    loader: `
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M10 3.2a6.8 6.8 0 1 1-4.81 1.99" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
    </svg>
  `
  };
  function normalizeUrl(rawUrl) {
    try {
      const url = new URL(rawUrl);
      url.hash = "";
      return url.toString();
    } catch {
      return rawUrl.trim();
    }
  }
  function readOptionalString(value) {
    const trimmed = typeof value === "string" ? value.trim() : void 0;
    return trimmed ? trimmed : void 0;
  }
  function normalizePreparePageCreditCap(value) {
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed <= 0) {
      return DEFAULT_PREPARE_PAGE_MAX_CREDITS;
    }
    return Math.max(
      MIN_PREPARE_PAGE_MAX_CREDITS,
      Math.min(MAX_PREPARE_PAGE_MAX_CREDITS, Math.floor(parsed))
    );
  }
  function normalizeCachingTtlSeconds(value) {
    const parsed = Number(value);
    if (parsed === ONE_DAY_CACHING_TTL_SECONDS) {
      return ONE_DAY_CACHING_TTL_SECONDS;
    }
    return DEFAULT_CACHING_TTL_SECONDS;
  }
  function getErrorCode(error) {
    return error && typeof error === "object" && "code" in error && typeof error.code === "string" && error.code.trim() ? error.code.trim() : void 0;
  }
  function getErrorStatus(error) {
    return error && typeof error === "object" && "status" in error && typeof error.status === "number" ? error.status : void 0;
  }
  function isExpiredTemplateCode(code) {
    return code === EMBEDDING_TEMPLATE_EXPIRED_CODE;
  }
  function isAbortError(error) {
    return Boolean(
      error instanceof DOMException && error.name === "AbortError" || error instanceof Error && error.name === "AbortError"
    );
  }
  function isPrivateHostname(hostname) {
    const normalized = hostname.toLowerCase();
    if (normalized === "localhost" || normalized === "::1" || normalized === "[::1]" || normalized.endsWith(".local")) {
      return true;
    }
    if (/^127\./.test(normalized) || /^10\./.test(normalized)) {
      return true;
    }
    if (/^192\.168\./.test(normalized)) {
      return true;
    }
    const match = normalized.match(/^172\.(\d{1,3})\./);
    if (!match) {
      return false;
    }
    const secondOctet = Number(match[1]);
    return Number.isInteger(secondOctet) && secondOctet >= 16 && secondOctet <= 31;
  }
  function getAnalyzeUrlError(rawUrl) {
    if (!rawUrl) {
      return "Open a page before starting document analysis.";
    }
    try {
      const url = new URL(rawUrl);
      if (!["http:", "https:"].includes(url.protocol)) {
        return "Only http and https pages can be analyzed.";
      }
      if (isPrivateHostname(url.hostname)) {
        return "Only public URLs can be analyzed. Local and private network pages are not supported.";
      }
      return void 0;
    } catch {
      return "This page URL is not valid for document analysis.";
    }
  }
  function getCurrentUserId() {
    return state.currentUser?.externalUserId ?? state.browserSessionId ?? "Unavailable";
  }
  function getCreditsRemaining() {
    return typeof state.currentUser?.generationCredits === "number" ? Math.max(0, Math.floor(state.currentUser.generationCredits)) : null;
  }
  function getVoiceConversationCreditRequirementMessage() {
    const creditsRemaining = getCreditsRemaining();
    if (state.registrationRequired || creditsRemaining === null || creditsRemaining >= MIN_VOICE_CONVERSATION_CREDITS) {
      return void 0;
    }
    return RECHARGE_CREDITS_MESSAGE;
  }
  async function enforceVoiceConversationCreditRequirement(input) {
    const message = getVoiceConversationCreditRequirementMessage();
    if (!message) {
      return false;
    }
    state.creditBannerDismissed = false;
    if (input?.stopConversation) {
      creditsRefreshPending = false;
      clearResumeConversationTimer();
      clearConversationIdleTimer();
      try {
        await stopPageRecordingCapture();
      } catch {
      }
      closeWebSocketSession({
        phase: "error",
        detail: "Recharge required"
      });
    }
    showNotification(message, 0, "recharge");
    render();
    return true;
  }
  function formatCreditsLabel(value) {
    const amount = creditCountFormatter.format(value);
    return `${amount} ${value === 1 ? "credit" : "credits"}`;
  }
  function getActiveAuthToken() {
    return state.externalUserApiKey ? void 0 : state.authToken;
  }
  function hasActiveSamsarCredentials() {
    return Boolean(state.externalUserApiKey || getActiveAuthToken());
  }
  function syncCreditIssueStateWithBalance() {
    const creditsRemaining = getCreditsRemaining();
    if (creditsRemaining !== null && creditsRemaining > 0) {
      state.creditIssueMessage = void 0;
      if (state.notificationAction === "recharge") {
        clearNotificationTimer();
        state.notificationMessage = void 0;
        state.notificationAction = void 0;
      }
    }
  }
  function isInsufficientCreditsMessage(message) {
    const normalized = readOptionalString(message);
    return Boolean(
      normalized && /not enough .*credits?|insufficient .*credits?|credits? are available|credits? remaining: 0|recharge credits?/i.test(
        normalized
      )
    );
  }
  function formatInsufficientCreditsMessage(message) {
    const normalized = readOptionalString(message);
    if (!normalized) {
      return RECHARGE_CREDITS_MESSAGE;
    }
    return isInsufficientCreditsMessage(normalized) ? RECHARGE_CREDITS_MESSAGE : normalized;
  }
  function getPreferredVoiceIdFromUser(user) {
    const browserInstallation = user?.browserInstallation;
    if (!browserInstallation || typeof browserInstallation !== "object") {
      return void 0;
    }
    const installation = browserInstallation;
    return readOptionalString(
      typeof installation.preferred_voice_id === "string" ? installation.preferred_voice_id : void 0
    ) ?? readOptionalString(
      typeof installation.preferredVoiceId === "string" ? installation.preferredVoiceId : void 0
    );
  }
  function getPreferredLanguageFromUser(user) {
    const browserInstallation = user?.browserInstallation;
    if (!browserInstallation || typeof browserInstallation !== "object") {
      return void 0;
    }
    const installation = browserInstallation;
    return readOptionalString(
      typeof installation.preferred_language === "string" ? installation.preferred_language : void 0
    ) ?? readOptionalString(
      typeof installation.preferredLanguage === "string" ? installation.preferredLanguage : void 0
    );
  }
  function getCachingTtlSecondsFromUser(user) {
    const browserInstallation = user?.browserInstallation;
    if (!browserInstallation || typeof browserInstallation !== "object") {
      return void 0;
    }
    const installation = browserInstallation;
    return normalizeCachingTtlSeconds(
      typeof installation.caching_ttl === "number" || typeof installation.caching_ttl === "string" ? installation.caching_ttl : typeof installation.cachingTtl === "number" || typeof installation.cachingTtl === "string" ? installation.cachingTtl : void 0
    );
  }
  function clearResumeConversationTimer() {
    if (typeof resumeConversationTimer === "number") {
      window.clearTimeout(resumeConversationTimer);
    }
    resumeConversationTimer = void 0;
  }
  function clearConversationIdleTimer() {
    if (typeof conversationIdleTimer === "number") {
      window.clearTimeout(conversationIdleTimer);
    }
    conversationIdleTimer = void 0;
  }
  function clearNotificationTimer() {
    if (typeof notificationTimer === "number") {
      window.clearTimeout(notificationTimer);
    }
    notificationTimer = void 0;
  }
  function clearPrepareStatusPollTimer() {
    if (typeof prepareStatusPollTimer === "number") {
      window.clearTimeout(prepareStatusPollTimer);
    }
    prepareStatusPollTimer = void 0;
  }
  function abortActiveAnalyzeRequest() {
    if (activeAnalyzeRequestController) {
      activeAnalyzeRequestController.abort();
      activeAnalyzeRequestController = void 0;
    }
  }
  function abortActiveTextRequest() {
    if (activeTextRequestController) {
      activeTextRequestController.abort();
      activeTextRequestController = void 0;
    }
  }
  function appendTextChatMessage(role, text, options) {
    const message = {
      id: crypto.randomUUID(),
      role,
      text,
      warnings: options?.warnings,
      pending: options?.pending
    };
    state.textMessages = [...state.textMessages, message];
    return message.id;
  }
  function updateTextChatMessage(messageId, updater) {
    if (!messageId) {
      return;
    }
    state.textMessages = state.textMessages.map(
      (message) => message.id === messageId ? updater(message) : message
    );
  }
  function clearPendingTextPromptState() {
    updateTextChatMessage(state.pendingTextMessageId, (message) => ({
      ...message,
      pending: false
    }));
    state.pendingTextPrompt = void 0;
    state.pendingTextMessageId = void 0;
  }
  function resetTextConversation() {
    abortActiveTextRequest();
    state.textDraft = "";
    state.textMessages = [];
    state.textSubmitting = false;
    state.pendingTextPrompt = void 0;
    state.pendingTextMessageId = void 0;
  }
  function buildTextChatMessages() {
    return state.textMessages.filter((message) => message.role === "user" || message.role === "assistant").map((message) => ({
      role: message.role,
      content: message.text
    }));
  }
  function renderTextChatThread() {
    if (!textChatThreadNode) {
      return;
    }
    textChatThreadNode.innerHTML = "";
    if (state.textMessages.length === 0) {
      const emptyState = document.createElement("div");
      const title = document.createElement("p");
      emptyState.className = "text-chat-empty";
      title.className = "text-chat-empty-title";
      title.textContent = state.analysisReady ? "Ask a question." : "Ready to chat.";
      emptyState.append(title);
      textChatThreadNode.append(emptyState);
      return;
    }
    for (const message of state.textMessages) {
      const article = document.createElement("article");
      const headerNode = document.createElement("div");
      const roleNode = document.createElement("p");
      const bodyNode = document.createElement("p");
      article.className = `text-chat-message text-chat-message-${message.role}`;
      if (message.pending) {
        article.classList.add("pending");
      }
      headerNode.className = "text-chat-message-header";
      roleNode.className = "text-chat-role";
      roleNode.textContent = message.role === "user" ? "You" : message.role === "assistant" ? "Assistant" : "System";
      headerNode.append(roleNode);
      if (message.role === "assistant" && !message.pending && message.text.trim()) {
        const copyButton = document.createElement("button");
        copyButton.className = "text-chat-copy-button";
        copyButton.type = "button";
        copyButton.dataset.textChatCopyId = message.id;
        copyButton.textContent = "Copy";
        headerNode.append(copyButton);
      }
      bodyNode.className = "text-chat-message-body";
      bodyNode.textContent = message.text;
      article.append(headerNode, bodyNode);
      if (message.warnings?.length) {
        for (const warning of message.warnings) {
          const warningNode = document.createElement("p");
          warningNode.className = "text-chat-warning";
          warningNode.textContent = warning;
          article.append(warningNode);
        }
      }
      textChatThreadNode.append(article);
    }
    textChatThreadNode.scrollTop = textChatThreadNode.scrollHeight;
  }
  function hideNotification() {
    clearNotificationTimer();
    if (!state.notificationMessage && !state.notificationAction) {
      return;
    }
    state.notificationMessage = void 0;
    state.notificationAction = void 0;
    render();
  }
  function showNotification(message, durationMs = NOTIFICATION_DURATION_MS, action) {
    clearNotificationTimer();
    state.notificationMessage = message;
    state.notificationAction = action;
    render();
    if (durationMs <= 0) {
      return;
    }
    notificationTimer = window.setTimeout(() => {
      notificationTimer = void 0;
      if (state.notificationMessage !== message) {
        return;
      }
      state.notificationMessage = void 0;
      state.notificationAction = void 0;
      render();
    }, durationMs);
  }
  function resetConversationIdleTimer() {
    clearConversationIdleTimer();
    if (!state.conversationActive && !state.recording && !state.assistantSpeaking) {
      return;
    }
    conversationIdleTimer = window.setTimeout(() => {
      void stopConversationMode({
        detail: "Idle timeout",
        logMessage: "Voice turned off after 10 minutes idle. Start voice when you're ready.",
        notificationMessage: "You've been idle for 10 minutes. Start voice when you're ready."
      });
    }, CONVERSATION_IDLE_TIMEOUT_MS);
  }
  function stopAssistantPlayback() {
    clearResumeConversationTimer();
    state.assistantSpeaking = false;
    if (activeAssistantAudio) {
      activeAssistantAudio.pause();
      activeAssistantAudio.src = "";
      activeAssistantAudio = void 0;
    }
    if (activeAssistantAudioObjectUrl) {
      URL.revokeObjectURL(activeAssistantAudioObjectUrl);
      activeAssistantAudioObjectUrl = void 0;
    }
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
  }
  function stopVoicePreviewPlayback() {
    if (activeVoicePreviewAudio) {
      activeVoicePreviewAudio.pause();
      activeVoicePreviewAudio.src = "";
      activeVoicePreviewAudio = void 0;
    }
    if (state.voicePreviewState !== "idle" || readOptionalString(state.voicePreviewVoiceId)) {
      state.voicePreviewState = "idle";
      state.voicePreviewVoiceId = void 0;
      renderVoicePreviewButton();
    }
  }
  function resumeConversationAfterVoicePreview() {
    if (!state.conversationActive || state.recording || state.assistantSpeaking) {
      return;
    }
    scheduleConversationResume(100);
  }
  async function toggleVoicePreviewPlayback() {
    const selectedVoiceId = getSelectedVoiceId();
    const previewSource = getSelectedVoicePreviewSource();
    if (!selectedVoiceId || !previewSource) {
      return;
    }
    const previewActive = state.voicePreviewVoiceId === selectedVoiceId && state.voicePreviewState !== "idle";
    if (previewActive) {
      stopVoicePreviewPlayback();
      return;
    }
    stopAssistantPlayback();
    stopVoicePreviewPlayback();
    const audio = new Audio(previewSource);
    activeVoicePreviewAudio = audio;
    state.voicePreviewVoiceId = selectedVoiceId;
    state.voicePreviewState = "loading";
    renderVoicePreviewButton();
    const cleanup = () => {
      if (activeVoicePreviewAudio === audio) {
        activeVoicePreviewAudio = void 0;
      }
      if (state.voicePreviewVoiceId === selectedVoiceId) {
        state.voicePreviewState = "idle";
        state.voicePreviewVoiceId = void 0;
        renderVoicePreviewButton();
      }
      resumeConversationAfterVoicePreview();
    };
    audio.addEventListener("play", () => {
      if (activeVoicePreviewAudio !== audio) {
        return;
      }
      state.voicePreviewState = "playing";
      renderVoicePreviewButton();
    });
    audio.addEventListener(
      "ended",
      () => {
        cleanup();
      },
      { once: true }
    );
    audio.addEventListener(
      "pause",
      () => {
        if (!audio.ended) {
          cleanup();
        }
      },
      { once: true }
    );
    audio.addEventListener(
      "error",
      () => {
        cleanup();
        appendLog("system", "Failed to play speaker preview.");
      },
      { once: true }
    );
    try {
      await audio.play();
    } catch (error) {
      const previewWasInterrupted = activeVoicePreviewAudio !== audio || state.voicePreviewVoiceId !== selectedVoiceId || error instanceof DOMException && error.name === "AbortError";
      cleanup();
      if (!previewWasInterrupted) {
        throw error;
      }
    }
  }
  async function requestOverlayClose() {
    stopVoicePreviewPlayback();
    await stopRecording();
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({
        type: "STRUCTUREDQUERIES_CLOSE_OVERLAY"
      }, "*");
      return;
    }
    window.close();
  }
  function isInjectableTabUrl(rawUrl) {
    if (!rawUrl) {
      return false;
    }
    try {
      const url = new URL(rawUrl);
      return ["http:", "https:"].includes(url.protocol);
    } catch {
      return false;
    }
  }
  function isMissingReceiverError(error) {
    return error instanceof Error && /Receiving end does not exist|Could not establish connection/i.test(
      error.message
    );
  }
  function setText(node, value) {
    if (node) {
      node.textContent = value;
    }
  }
  function syncPreparePageCreditCapInput() {
    if (!prepareMaxCreditsInput) {
      return;
    }
    prepareMaxCreditsInput.value = String(state.maxPrepareCredits);
  }
  function syncCachingTtlInput() {
    if (!cachingTtlSelect) {
      return;
    }
    cachingTtlSelect.value = String(state.cachingTtlSeconds);
  }
  function setIcon(node, icon) {
    if (node) {
      node.innerHTML = BUTTON_ICONS[icon];
    }
  }
  function setButtonVariant(button, variant) {
    if (!button) {
      return;
    }
    button.classList.toggle("primary-button", variant === "primary");
    button.classList.toggle("secondary-button", variant === "secondary");
    button.classList.toggle("danger-button", variant === "danger");
  }
  function dismissCreditBanner(event) {
    event?.preventDefault();
    event?.stopPropagation();
    state.creditBannerDismissed = true;
    if (creditWarningNode) {
      creditWarningNode.hidden = true;
      creditWarningNode.style.display = "none";
    }
    render();
  }
  async function writeTextToClipboard(value) {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value);
      return;
    }
    const textArea = document.createElement("textarea");
    textArea.value = value;
    textArea.setAttribute("readonly", "true");
    textArea.style.position = "fixed";
    textArea.style.opacity = "0";
    textArea.style.pointerEvents = "none";
    document.body.append(textArea);
    textArea.select();
    const copied = document.execCommand("copy");
    document.body.removeChild(textArea);
    if (!copied) {
      throw new Error("Clipboard access is unavailable.");
    }
  }
  async function copyTextChatMessage(messageId) {
    const message = state.textMessages.find((entry) => entry.id === messageId);
    const text = readOptionalString(message?.text);
    if (!text) {
      return;
    }
    try {
      await writeTextToClipboard(text);
      showNotification("Copied.");
    } catch (error) {
      console.error("Failed to copy text chat response", error);
      showNotification("Copy failed.");
    }
  }
  function normalizeWebSocketPhase(phase) {
    switch (phase) {
      case "connected":
      case "ready":
      case "transcribing":
      case "thinking":
      case "synthesizing":
      case "idle":
      case "error":
        return phase;
      default:
        return "idle";
    }
  }
  function appendLog(role, text) {
    if (!conversationLogNode) {
      return;
    }
    const article = document.createElement("article");
    const roleNode = document.createElement("p");
    const textNode = document.createElement("p");
    article.className = `log-item log-item-${role}`;
    roleNode.className = "log-role";
    roleNode.textContent = role === "user" ? "You" : role === "assistant" ? "Structure Queries" : "System";
    textNode.className = "log-text";
    textNode.textContent = text;
    article.append(roleNode, textNode);
    conversationLogNode.append(article);
    conversationLogNode.scrollTop = conversationLogNode.scrollHeight;
  }
  function appendImageLog(role, imageSource, caption) {
    if (!conversationLogNode) {
      return;
    }
    const article = document.createElement("article");
    const roleNode = document.createElement("p");
    const imageNode = document.createElement("img");
    article.className = `log-item log-item-${role}`;
    roleNode.className = "log-role";
    roleNode.textContent = role;
    imageNode.className = "log-image";
    imageNode.src = imageSource.imageUrl ? imageSource.imageUrl : `data:${imageSource.mimeType};base64,${imageSource.imageBase64 ?? ""}`;
    imageNode.alt = caption || `${role} image response`;
    article.append(roleNode);
    if (caption) {
      const captionNode = document.createElement("p");
      captionNode.className = "log-text";
      captionNode.textContent = caption;
      article.append(captionNode);
    }
    article.append(imageNode);
    conversationLogNode.append(article);
    conversationLogNode.scrollTop = conversationLogNode.scrollHeight;
  }
  function resetConversationLog() {
    if (!conversationLogNode) {
      return;
    }
    conversationLogNode.innerHTML = "";
    appendLog("system", "Prepare the page, then ask by voice.");
  }
  function renderVoiceOptions() {
    if (!voiceSelect) {
      renderVoicePreviewButton();
      return;
    }
    const preferredVoiceId = readOptionalString(state.preferredVoiceId);
    const preferredVoiceName = readOptionalString(state.preferredVoiceName);
    voiceSelect.innerHTML = "";
    for (const voice of state.voices) {
      const option = document.createElement("option");
      option.value = voice.voiceId;
      option.textContent = voice.name;
      option.title = voice.description ?? voice.name;
      voiceSelect.append(option);
    }
    if (preferredVoiceId && !state.voices.some((voice) => voice.voiceId === preferredVoiceId)) {
      const option = document.createElement("option");
      option.value = preferredVoiceId;
      option.textContent = preferredVoiceName ?? "Saved speaker";
      option.title = preferredVoiceName ?? "Saved speaker";
      voiceSelect.append(option);
    }
    if (voiceSelect.options.length === 0) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "Browser voice fallback";
      voiceSelect.append(option);
    }
    const matchingValue = preferredVoiceId && Array.from(voiceSelect.options).some((option) => option.value === preferredVoiceId) ? preferredVoiceId : state.voices[0]?.voiceId ?? "";
    voiceSelect.value = matchingValue;
    if (preferredVoiceId && matchingValue === preferredVoiceId) {
      state.preferredVoiceName = readOptionalString(voiceSelect.selectedOptions[0]?.textContent) ?? preferredVoiceName;
    }
    if (state.voicePreviewState !== "idle" && (state.voicePreviewVoiceId !== getSelectedVoiceId() || !getSelectedVoicePreviewSource())) {
      stopVoicePreviewPlayback();
      return;
    }
    renderVoicePreviewButton();
  }
  function getSelectedVoiceId() {
    const value = readOptionalString(voiceSelect?.value);
    return value ?? readOptionalString(state.preferredVoiceId);
  }
  function getSelectedLanguage() {
    return readOptionalString(languageSelect?.value) ?? "auto";
  }
  function setSelectedLanguage(language) {
    if (!languageSelect) {
      return;
    }
    const nextLanguage = readOptionalString(language) ?? "auto";
    if (Array.from(languageSelect.options).some(
      (option) => option.value === nextLanguage
    )) {
      languageSelect.value = nextLanguage;
    }
  }
  function getSelectedVoiceOption() {
    const selectedVoiceId = getSelectedVoiceId();
    if (!selectedVoiceId) {
      return void 0;
    }
    return state.voices.find((voice) => voice.voiceId === selectedVoiceId);
  }
  function getSelectedVoiceName() {
    return readOptionalString(getSelectedVoiceOption()?.name) ?? readOptionalString(voiceSelect?.selectedOptions[0]?.textContent) ?? readOptionalString(state.preferredVoiceName);
  }
  function getSelectedVoicePreviewSource() {
    const selectedVoice = getSelectedVoiceOption();
    if (!selectedVoice?.previewUrl) {
      return void 0;
    }
    return `${SERVER_HTTP_ORIGIN}/api/voices/preview?voiceId=${encodeURIComponent(
      selectedVoice.voiceId
    )}`;
  }
  function syncLanguagePreferenceToSocket() {
    if (activeSocket?.readyState !== WebSocket.OPEN) {
      return;
    }
    sendSocketMessage({
      type: "set_language",
      language: getSelectedLanguage()
    });
  }
  function renderVoicePreviewButton() {
    if (!voicePreviewButton) {
      return;
    }
    const selectedVoiceId = getSelectedVoiceId();
    const previewSource = getSelectedVoicePreviewSource();
    const previewActive = Boolean(
      selectedVoiceId && state.voicePreviewVoiceId === selectedVoiceId && state.voicePreviewState !== "idle"
    );
    const voiceBusy = state.recording || state.assistantSpeaking;
    voicePreviewButton.disabled = !previewSource || state.registrationSubmitting || state.isInitializing || voiceBusy && !previewActive;
    voicePreviewButton.textContent = !previewSource ? "Preview unavailable" : previewActive && state.voicePreviewState === "playing" ? "Pause preview" : previewActive && state.voicePreviewState === "loading" ? "Loading preview..." : "Play preview";
  }
  function syncRegistrationForm() {
    if (registrationDisplayNameNode) {
      registrationDisplayNameNode.value = state.currentUser?.displayName ?? "";
    }
    if (registrationEmailNode) {
      registrationEmailNode.value = state.currentUser?.email ?? "";
    }
    if (registrationUsernameNode) {
      registrationUsernameNode.value = state.currentUser?.username ?? "";
    }
  }
  function openAccountEditor() {
    state.accountEditorOpen = true;
    syncRegistrationForm();
    render();
    if (state.serverOnline) {
      void ensureVoicesLoaded().catch((error) => {
        console.error("Failed to load speakers for account settings", error);
      });
    }
  }
  function closeAccountEditor() {
    if (state.registrationRequired || state.registrationSubmitting) {
      return;
    }
    state.accountEditorOpen = false;
    render();
  }
  async function setInteractionMode(mode) {
    if (state.interactionMode === mode) {
      return;
    }
    if (mode === "text" && (state.conversationActive || state.recording || state.assistantSpeaking)) {
      await stopRecording();
    }
    if (mode === "text" && activeSocket) {
      closeWebSocketSession({
        phase: "idle",
        detail: "Idle"
      });
    }
    state.interactionMode = mode;
    render();
  }
  function render() {
    const creditIssueActive = Boolean(state.creditIssueMessage);
    const analyzeUrlError = getAnalyzeUrlError(state.currentPage?.url);
    const waitingForAssistant = state.conversationActive && !state.recording && !state.assistantSpeaking && ["transcribing", "thinking", "synthesizing"].includes(state.websocketPhase);
    const voiceBusy = state.conversationActive || state.recording || state.assistantSpeaking || waitingForAssistant;
    const textBusy = state.textSubmitting || Boolean(state.pendingTextPrompt);
    const creditsRemaining = getCreditsRemaining();
    const voiceCreditRequirementMessage = getVoiceConversationCreditRequirementMessage();
    const voiceCreditsBlocked = Boolean(voiceCreditRequirementMessage);
    const showVoiceCreditRequirement = state.interactionMode === "voice" && voiceCreditsBlocked;
    const lowCreditsActive = !state.registrationRequired && creditsRemaining !== null && creditsRemaining < LOW_CREDIT_WARNING_THRESHOLD;
    const creditBannerAvailable = creditIssueActive || lowCreditsActive;
    if (!creditBannerAvailable && state.creditBannerDismissed) {
      state.creditBannerDismissed = false;
    }
    const showCreditBanner = showVoiceCreditRequirement || creditBannerAvailable && !state.creditBannerDismissed;
    const accountName = readOptionalString(state.currentUser?.displayName) ?? readOptionalString(state.currentUser?.username) ?? readOptionalString(state.currentUser?.email) ?? (state.registrationRequired ? "Setup required" : "Structure Queries");
    const headerCreditsValue = state.registrationRequired ? `${STARTER_CREDITS} starter` : creditsRemaining === null ? "-- cr" : `${creditCountFormatter.format(creditsRemaining)} cr`;
    const settingsCreditsValue = state.registrationRequired ? `${STARTER_CREDITS} starter credits` : creditsRemaining === null ? "Unavailable" : formatCreditsLabel(creditsRemaining);
    const settingsCreditsCaption = state.registrationRequired ? "Connect Samsar One to use your existing balance, or finish a client-only setup to receive starter credits." : creditIssueActive ? "Recharge in Samsar, then return here and refresh the session." : creditsRemaining === null ? "Refresh the session to load your latest balance." : "Open the Samsar app to recharge when you need more.";
    const analysisPill = state.isInitializing ? "Loading" : textBusy ? "Replying" : state.isAnalyzing ? "Scanning" : !state.serverOnline ? "Offline" : state.registrationRequired ? "Register" : creditIssueActive ? "Recharge" : analyzeUrlError ? "Blocked" : state.pageCacheExpired ? "Expired" : state.recording ? "Listening" : state.assistantSpeaking ? "Speaking" : waitingForAssistant ? "Thinking" : state.conversationActive ? "Live" : state.analysisReady ? "Ready" : "Prepare";
    const surfaceStatus = state.isInitializing ? "Syncing session..." : !state.serverOnline ? "Server offline." : state.registrationRequired ? "Finish setup to unlock page QA." : creditIssueActive ? "Recharge required." : analyzeUrlError ? analyzeUrlError : state.pageCacheExpired ? EXPIRED_PAGE_CACHE_MESSAGE : state.interactionMode === "text" ? textBusy && state.pendingTextPrompt ? "Preparing the page before answering..." : textBusy ? "Writing a grounded reply..." : state.isAnalyzing ? "Building page context..." : voiceBusy ? "Voice is active. Stop voice to use text." : state.analysisReady ? "Ready for text questions." : "Ask in text and the page will be prepared first." : state.isAnalyzing ? "Building page context..." : state.recording ? "Listening for your question..." : state.assistantSpeaking ? "Speaking the answer..." : waitingForAssistant ? state.websocketPhase === "transcribing" ? "Transcribing your question..." : state.websocketPhase === "synthesizing" ? "Preparing voice reply..." : "Thinking..." : state.conversationActive ? "Voice chat is live." : state.analysisReady ? "Ready for voice questions." : "Prepare this page once to start QA.";
    const analysisDetail = state.isInitializing ? "Loading client state." : !state.serverOnline ? "Server unavailable." : state.registrationRequired ? "Finish setup to continue." : creditIssueActive ? "This client is blocked until credits are recharged in Samsar." : analyzeUrlError ? analyzeUrlError : state.pageCacheExpired ? "Prepared page cache expired and must be prepared again." : state.interactionMode === "text" ? textBusy && state.pendingTextPrompt ? "Preparing the page, then sending your question automatically." : textBusy ? "Running the text query through retrieval and grounded completion." : state.isAnalyzing ? "Reading and indexing this page." : voiceBusy ? "Voice mode is currently active." : state.analysisReady ? "Text mode is ready." : "Type a question to prepare the page and answer in text." : state.isAnalyzing ? "Reading and indexing this page." : state.recording ? "Listening." : state.assistantSpeaking ? "Speaking." : waitingForAssistant ? state.websocketDetail || "Generating assistant reply." : state.conversationActive ? "Voice chat live." : state.analysisReady ? "Ready when you are." : "Create page context first.";
    const textStatus = state.isInitializing ? "Syncing session..." : !state.serverOnline ? "Server offline." : state.registrationRequired ? "Finish setup." : creditIssueActive ? "Recharge required." : analyzeUrlError ? analyzeUrlError : state.pageCacheExpired ? "Prepare again." : textBusy && state.pendingTextPrompt ? "Preparing page..." : textBusy ? "Replying..." : state.isAnalyzing ? "Preparing page..." : voiceBusy ? "Stop voice first." : state.analysisReady ? "Ready." : "Ask a question.";
    const registrationDialogOpen = !state.isInitializing && (state.registrationRequired || state.accountEditorOpen);
    const registrationMode = state.registrationRequired ? "register" : "edit";
    const voiceMode = state.isInitializing ? "loading" : !state.serverOnline ? "offline" : state.isAnalyzing ? "analyzing" : state.recording ? "listening" : state.assistantSpeaking ? "speaking" : waitingForAssistant ? "thinking" : state.websocketState === "connecting" ? "connecting" : state.conversationActive ? "armed" : state.analysisReady ? "ready" : analyzeUrlError ? "error" : "idle";
    const voiceButtonDisabled = state.isInitializing || state.registrationRequired || state.registrationSubmitting || !state.serverOnline || creditIssueActive || !state.analysisReady || !state.currentPage?.url || state.isAnalyzing || state.textSubmitting || state.websocketState === "connecting" || !voiceBusy && voiceCreditsBlocked;
    const voiceButtonLabel = state.websocketState === "connecting" ? "Connecting..." : voiceBusy ? "Stop voice" : voiceCreditsBlocked ? `Need ${MIN_VOICE_CONVERSATION_CREDITS} credits` : state.analysisReady ? "Start voice" : "Voice after scan";
    const analyzeButtonLabelText = state.isAnalyzing ? "Preparing..." : state.analysisReady ? "Redo scan" : "Prepare page";
    const textSubmitButtonDisabled = state.isInitializing || state.registrationRequired || state.registrationSubmitting || !state.serverOnline || creditIssueActive || Boolean(analyzeUrlError) || !state.currentPage?.url || state.isAnalyzing || textBusy || voiceBusy || !readOptionalString(state.textDraft);
    const textSubmitButtonLabelText = textBusy ? state.pendingTextPrompt ? "Preparing..." : "Sending..." : "Send";
    const creditBannerMessage = creditIssueActive ? RECHARGE_CREDITS_MESSAGE : showVoiceCreditRequirement ? voiceCreditRequirementMessage ?? "" : lowCreditsActive && creditsRemaining !== null ? creditsRemaining < RECHARGE_CREDITS_THRESHOLD ? RECHARGE_CREDITS_MESSAGE : `${creditCountFormatter.format(creditsRemaining)} credits left.` : "";
    setText(surfaceStatusNode, surfaceStatus);
    setText(accountNameNode, accountName);
    setText(
      accountHintNode,
      state.registrationRequired ? "Setup is required." : creditIssueActive ? "Recharge required." : creditsRemaining !== null ? `${formatCreditsLabel(creditsRemaining)} remaining.` : state.currentUser?.email ? "Ready." : "Connected."
    );
    setText(
      accountEmailNode,
      readOptionalString(state.currentUser?.email) ?? "Not provided"
    );
    setText(
      accountUsernameNode,
      readOptionalString(state.currentUser?.username) ?? "Not provided"
    );
    setText(accountUserIdNode, getCurrentUserId());
    setText(headerCreditsNode, headerCreditsValue);
    setText(analysisPillNode, analysisPill);
    setText(
      pageTitleNode,
      state.currentPage?.title ?? "Current page"
    );
    setText(
      pageUrlNode,
      state.currentPage?.url ?? "No page selected"
    );
    setText(
      pageLanguageNode,
      `Language: ${state.currentPage?.documentLanguage || "unknown"}`
    );
    setText(analysisStatusNode, analysisDetail);
    setText(
      registrationEyebrowNode,
      registrationMode === "register" ? "Set up" : "Account"
    );
    setText(
      registrationTitleNode,
      registrationMode === "register" ? "Set up Structure Queries" : "Update Account"
    );
    setText(
      registrationSubtitleNode,
      registrationMode === "register" ? "Use Samsar One for your existing account and credits, or keep a client-only profile in this browser." : "Update your session profile."
    );
    setText(
      registrationStatusNode,
      !state.serverOnline ? "Server must be online." : state.registrationSubmitting ? registrationMode === "register" ? "Setting up..." : "Saving..." : state.samsarAuthSubmitting ? "Connecting with Samsar One..." : state.loginLinkSubmitting ? "Opening Samsar..." : registrationMode === "register" ? "Connect Samsar One to use your existing account and credits, or register a client-only profile here." : creditIssueActive ? state.creditIssueMessage ?? "Recharge credits to continue." : "Save changes."
    );
    setText(settingsCreditsRemainingNode, settingsCreditsValue);
    setText(settingsCreditsCaptionNode, settingsCreditsCaption);
    setText(voiceWarningNode, state.voiceWarning ?? "");
    setText(creditWarningMessageNode, creditBannerMessage);
    setText(notificationMessageNode, state.notificationMessage ?? "");
    setText(textChatStatusNode, textStatus);
    if (voiceWarningNode) {
      voiceWarningNode.hidden = !state.voiceWarning;
    }
    if (creditWarningNode) {
      creditWarningNode.hidden = !showCreditBanner;
      creditWarningNode.style.display = showCreditBanner ? "" : "none";
    }
    if (creditWarningDismissButton) {
      creditWarningDismissButton.hidden = showVoiceCreditRequirement;
      creditWarningDismissButton.disabled = showVoiceCreditRequirement;
    }
    if (notificationNode) {
      notificationNode.hidden = !state.notificationMessage;
    }
    if (notificationActionButton) {
      notificationActionButton.hidden = !state.notificationAction;
      notificationActionButton.disabled = state.notificationAction === "recharge" && state.loginLinkSubmitting;
      notificationActionButton.textContent = state.notificationAction === "recharge" ? state.loginLinkSubmitting ? "Opening..." : "Recharge credits" : "";
    }
    document.body.dataset.loading = state.isInitializing ? "true" : "false";
    document.body.dataset.voiceMode = voiceMode;
    document.body.dataset.interactionMode = state.interactionMode;
    if (overlayShellNode) {
      overlayShellNode.setAttribute("aria-busy", state.isInitializing ? "true" : "false");
    }
    if (interactionModeVoiceButton) {
      interactionModeVoiceButton.disabled = state.isInitializing;
      interactionModeVoiceButton.setAttribute(
        "aria-selected",
        String(state.interactionMode === "voice")
      );
    }
    if (interactionModeTextButton) {
      interactionModeTextButton.disabled = state.isInitializing;
      interactionModeTextButton.setAttribute(
        "aria-selected",
        String(state.interactionMode === "text")
      );
    }
    if (voiceModeShellNode) {
      voiceModeShellNode.hidden = state.interactionMode !== "voice";
    }
    if (textModeShellNode) {
      textModeShellNode.hidden = state.interactionMode !== "text";
    }
    if (registrationOverlayNode) {
      registrationOverlayNode.classList.toggle("is-hidden", !registrationDialogOpen);
    }
    if (registrationCloseButton) {
      registrationCloseButton.disabled = state.registrationRequired || state.registrationSubmitting;
      registrationCloseButton.hidden = state.registrationRequired;
    }
    if (registrationSubmitButton) {
      registrationSubmitButton.disabled = state.registrationSubmitting || state.samsarAuthSubmitting || state.loginLinkSubmitting || !state.serverOnline;
      registrationSubmitButton.textContent = state.registrationSubmitting ? registrationMode === "register" ? "Registering..." : "Saving..." : registrationMode === "register" ? "Register" : "Save Changes";
    }
    if (samsarAuthButton) {
      samsarAuthButton.hidden = registrationMode !== "register";
      samsarAuthButton.disabled = state.registrationSubmitting || state.samsarAuthSubmitting || state.loginLinkSubmitting || !state.serverOnline;
      samsarAuthButton.textContent = state.samsarAuthSubmitting ? "Connecting..." : "Continue with Samsar One";
    }
    if (authHelperCopyNode) {
      authHelperCopyNode.hidden = registrationMode !== "register";
    }
    if (samsarLoginButton) {
      samsarLoginButton.hidden = registrationMode === "register";
      samsarLoginButton.disabled = state.registrationRequired || state.registrationSubmitting || state.samsarAuthSubmitting || state.loginLinkSubmitting || !state.serverOnline;
      samsarLoginButton.textContent = state.loginLinkSubmitting ? "Opening Samsar..." : "Recharge Credits";
    }
    if (creditWarningButton) {
      creditWarningButton.disabled = state.registrationRequired || state.registrationSubmitting || state.samsarAuthSubmitting || state.loginLinkSubmitting || !state.serverOnline;
      creditWarningButton.textContent = state.loginLinkSubmitting ? "Opening Samsar..." : "Recharge Credits";
    }
    if (analyzeButton) {
      analyzeButton.disabled = state.isInitializing || state.registrationRequired || state.registrationSubmitting || !state.serverOnline || creditIssueActive || Boolean(analyzeUrlError) || state.isAnalyzing || voiceBusy || state.textSubmitting;
      analyzeButton.classList.toggle("button-chip", state.analysisReady);
      setButtonVariant(analyzeButton, state.analysisReady ? "secondary" : "primary");
    }
    setText(analyzeButtonLabel, analyzeButtonLabelText);
    setIcon(
      analyzeButtonIcon,
      state.isAnalyzing ? "loader" : state.analysisReady ? "redo" : "scan"
    );
    if (textAnalyzeButton) {
      textAnalyzeButton.disabled = state.isInitializing || state.registrationRequired || state.registrationSubmitting || !state.serverOnline || creditIssueActive || Boolean(analyzeUrlError) || state.isAnalyzing || voiceBusy || state.textSubmitting;
      setButtonVariant(
        textAnalyzeButton,
        state.analysisReady ? "secondary" : "primary"
      );
    }
    setText(textAnalyzeButtonLabel, analyzeButtonLabelText);
    setIcon(
      textAnalyzeButtonIcon,
      state.isAnalyzing ? "loader" : state.analysisReady ? "redo" : "scan"
    );
    if (voiceToggleButton) {
      voiceToggleButton.disabled = voiceButtonDisabled;
      voiceToggleButton.classList.toggle("button-live", voiceBusy);
      setButtonVariant(
        voiceToggleButton,
        voiceBusy ? "danger" : state.analysisReady ? "primary" : "secondary"
      );
    }
    setText(voiceToggleButtonLabel, voiceButtonLabel);
    setIcon(voiceToggleButtonIcon, voiceBusy ? "stop" : "mic");
    if (buttonRowNode) {
      buttonRowNode.classList.toggle("button-row-ready", state.analysisReady);
    }
    if (voiceSelect) {
      voiceSelect.disabled = state.registrationSubmitting || state.samsarAuthSubmitting || state.isInitializing;
    }
    if (cachingTtlSelect) {
      if (cachingTtlSelect.value !== String(state.cachingTtlSeconds)) {
        cachingTtlSelect.value = String(state.cachingTtlSeconds);
      }
      cachingTtlSelect.disabled = state.registrationSubmitting || state.samsarAuthSubmitting || state.isInitializing;
    }
    renderVoicePreviewButton();
    renderTextChatThread();
    if (languageSelect) {
      languageSelect.disabled = state.registrationSubmitting || state.samsarAuthSubmitting || state.registrationRequired || state.isInitializing;
    }
    if (registrationDisplayNameNode) {
      registrationDisplayNameNode.disabled = state.registrationSubmitting || state.samsarAuthSubmitting;
    }
    if (registrationEmailNode) {
      registrationEmailNode.disabled = state.registrationSubmitting || state.samsarAuthSubmitting;
    }
    if (registrationUsernameNode) {
      registrationUsernameNode.disabled = state.registrationSubmitting || state.samsarAuthSubmitting;
    }
    if (textChatInputNode) {
      if (textChatInputNode.value !== state.textDraft) {
        textChatInputNode.value = state.textDraft;
      }
      textChatInputNode.disabled = state.isInitializing || state.registrationRequired || !state.serverOnline || creditIssueActive || Boolean(analyzeUrlError) || !state.currentPage?.url || state.isAnalyzing || textBusy || voiceBusy;
    }
    if (textChatSubmitButton) {
      textChatSubmitButton.disabled = textSubmitButtonDisabled;
    }
    setText(textChatSubmitButtonLabel, textSubmitButtonLabelText);
    setIcon(textChatSubmitButtonIcon, textBusy ? "loader" : "send");
    if (accountButton) {
      accountButton.disabled = state.registrationSubmitting || state.samsarAuthSubmitting || state.isInitializing;
    }
  }
  async function fetchJson(path, init) {
    const response = await fetch(`${SERVER_HTTP_ORIGIN}${path}`, init);
    if (!response.ok) {
      let errorMessage = `Request failed with ${response.status}`;
      let errorCode;
      try {
        const payload = await response.json();
        if (typeof payload.code === "string" && payload.code.trim()) {
          errorCode = payload.code.trim();
        }
        if (typeof payload.error === "string" && payload.error.trim()) {
          errorMessage = payload.error.trim();
        } else if (typeof payload.message === "string" && payload.message.trim()) {
          errorMessage = payload.message.trim();
        }
      } catch {
      }
      const error = new Error(errorMessage);
      error.code = errorCode;
      error.status = response.status;
      throw error;
    }
    return await response.json();
  }
  async function getExtensionSession() {
    return chrome.runtime.sendMessage({
      type: "GET_EXTENSION_SESSION"
    });
  }
  function buildSessionCredentialPayload() {
    return {
      authToken: getActiveAuthToken(),
      browserSessionId: state.browserSessionId,
      externalUserApiKey: state.externalUserApiKey
    };
  }
  async function requestPageContextFromTab(tabId) {
    return await chrome.tabs.sendMessage(tabId, {
      type: "GET_PAGE_CONTEXT"
    });
  }
  async function getActiveTab() {
    const [activeTab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    return activeTab;
  }
  async function sendMessageToClientTab(message) {
    const activeTab = await getActiveTab();
    const tabId = typeof state.hostTabId === "number" ? state.hostTabId : activeTab?.id;
    const tabUrl = state.currentPage?.url ?? (typeof state.hostTabId === "number" ? void 0 : activeTab?.url);
    if (typeof tabId !== "number") {
      throw new Error("No active browser tab is available.");
    }
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (error) {
      if (isMissingReceiverError(error) && isInjectableTabUrl(tabUrl)) {
        await chrome.scripting.executeScript({
          target: {
            tabId
          },
          files: ["content.js"]
        });
        return await chrome.tabs.sendMessage(tabId, message);
      }
      throw error;
    }
  }
  async function stopPageRecordingCapture() {
    try {
      const response = await sendMessageToClientTab({
        type: "STOP_PAGE_RECORDING"
      });
      if (!response?.ok && response?.error) {
        console.warn("Failed to stop page recording", response.error);
      }
    } catch (error) {
      console.warn("Failed to stop page recording", error);
    }
  }
  function showInsufficientCreditsState(message) {
    const issueMessage = formatInsufficientCreditsMessage(message);
    creditsRefreshPending = false;
    creditsRefreshInFlight = false;
    abortActiveTextRequest();
    if (state.currentUser) {
      state.currentUser = {
        ...state.currentUser,
        generationCredits: 0
      };
    }
    state.creditIssueMessage = issueMessage;
    state.creditBannerDismissed = false;
    clearPendingTextPromptState();
    state.textSubmitting = false;
    void stopPageRecordingCapture();
    closeWebSocketSession({
      phase: "error",
      detail: "Recharge required"
    });
    showNotification(issueMessage, 0, "recharge");
    render();
    void saveCurrentRegistrationState().catch((error) => {
      console.error("Failed to persist depleted credit balance", error);
    });
  }
  async function fetchPageContext() {
    const activeTab = await getActiveTab();
    const hostTabId = typeof state.hostTabId === "number" ? state.hostTabId : void 0;
    if (!activeTab && typeof hostTabId !== "number") {
      return void 0;
    }
    let pageContext;
    if (typeof hostTabId === "number") {
      try {
        pageContext = await requestPageContextFromTab(hostTabId);
      } catch (error) {
        if (isMissingReceiverError(error) && isInjectableTabUrl(state.currentPage?.url)) {
          try {
            await chrome.scripting.executeScript({
              target: {
                tabId: hostTabId
              },
              files: ["content.js"]
            });
            pageContext = await requestPageContextFromTab(hostTabId);
          } catch (retryError) {
            console.warn(
              "Failed to inject content script into active tab",
              retryError
            );
          }
        } else if (!isMissingReceiverError(error)) {
          console.warn("Failed to fetch page context from active tab", error);
        }
      }
    }
    return {
      title: pageContext?.title ?? activeTab?.title ?? state.currentPage?.title ?? "Untitled page",
      url: pageContext?.url ?? state.currentPage?.url ?? activeTab?.url,
      documentLanguage: pageContext?.documentLanguage ?? state.currentPage?.documentLanguage
    };
  }
  async function getAnalyzedPagesCache() {
    const stored = await chrome.storage.local.get([
      ANALYZED_PAGES_STORAGE_KEY,
      LEGACY_ANALYZED_PAGES_STORAGE_KEY
    ]);
    const cache = stored[ANALYZED_PAGES_STORAGE_KEY] ?? stored[LEGACY_ANALYZED_PAGES_STORAGE_KEY];
    if (!cache || typeof cache !== "object") {
      return {};
    }
    if (stored[ANALYZED_PAGES_STORAGE_KEY] === void 0 && stored[LEGACY_ANALYZED_PAGES_STORAGE_KEY] !== void 0) {
      await chrome.storage.local.set({
        [ANALYZED_PAGES_STORAGE_KEY]: cache
      });
      await chrome.storage.local.remove(LEGACY_ANALYZED_PAGES_STORAGE_KEY);
    }
    return cache;
  }
  async function markPageAnalyzed(url, entry) {
    const cache = await getAnalyzedPagesCache();
    cache[normalizeUrl(url)] = entry;
    await chrome.storage.local.set({
      [ANALYZED_PAGES_STORAGE_KEY]: cache
    });
  }
  async function clearAnalyzedPage(url) {
    const cache = await getAnalyzedPagesCache();
    const normalizedUrl = normalizeUrl(url);
    if (!(normalizedUrl in cache)) {
      return;
    }
    delete cache[normalizedUrl];
    await chrome.storage.local.set({
      [ANALYZED_PAGES_STORAGE_KEY]: cache
    });
  }
  async function getAnalyzedPageState(url) {
    const cache = await getAnalyzedPagesCache();
    return cache[normalizeUrl(url)];
  }
  async function getPreparePageRequestsCache() {
    const stored = await chrome.storage.local.get(PREPARE_PAGE_REQUESTS_STORAGE_KEY);
    const cache = stored[PREPARE_PAGE_REQUESTS_STORAGE_KEY];
    if (!cache || typeof cache !== "object") {
      return {};
    }
    return cache;
  }
  async function savePendingPreparePageRequest(url, entry) {
    const cache = await getPreparePageRequestsCache();
    cache[normalizeUrl(url)] = entry;
    await chrome.storage.local.set({
      [PREPARE_PAGE_REQUESTS_STORAGE_KEY]: cache
    });
  }
  async function removePendingPreparePageRequest(url, requestId) {
    const cache = await getPreparePageRequestsCache();
    const normalizedUrl = normalizeUrl(url);
    const existing = cache[normalizedUrl];
    if (!existing) {
      return;
    }
    if (requestId && existing.requestId !== requestId) {
      return;
    }
    delete cache[normalizedUrl];
    await chrome.storage.local.set({
      [PREPARE_PAGE_REQUESTS_STORAGE_KEY]: cache
    });
  }
  async function getPendingPreparePageRequest(url) {
    const cache = await getPreparePageRequestsCache();
    return cache[normalizeUrl(url)];
  }
  async function getRegistrationState(browserSessionId) {
    const stored = await chrome.storage.local.get([
      REGISTRATION_STORAGE_KEY,
      LEGACY_REGISTRATION_STORAGE_KEY
    ]);
    const registration = stored[REGISTRATION_STORAGE_KEY] ?? stored[LEGACY_REGISTRATION_STORAGE_KEY];
    if (!registration || typeof registration !== "object") {
      return null;
    }
    const payload = registration;
    if (payload.browserSessionId !== browserSessionId) {
      return null;
    }
    if (stored[REGISTRATION_STORAGE_KEY] === void 0 && stored[LEGACY_REGISTRATION_STORAGE_KEY] !== void 0) {
      await chrome.storage.local.set({
        [REGISTRATION_STORAGE_KEY]: registration
      });
      await chrome.storage.local.remove(LEGACY_REGISTRATION_STORAGE_KEY);
    }
    return payload;
  }
  async function loadPreparePageSettings() {
    const stored = await chrome.storage.local.get(PREPARE_PAGE_SETTINGS_STORAGE_KEY);
    const payload = stored[PREPARE_PAGE_SETTINGS_STORAGE_KEY];
    if (!payload || typeof payload !== "object") {
      state.cachingTtlSeconds = DEFAULT_CACHING_TTL_SECONDS;
      state.maxPrepareCredits = DEFAULT_PREPARE_PAGE_MAX_CREDITS;
      syncCachingTtlInput();
      syncPreparePageCreditCapInput();
      return;
    }
    state.cachingTtlSeconds = normalizeCachingTtlSeconds(
      payload.cachingTtlSeconds
    );
    state.maxPrepareCredits = normalizePreparePageCreditCap(
      payload.maxPrepareCredits
    );
    syncCachingTtlInput();
    syncPreparePageCreditCapInput();
  }
  async function savePreparePageSettings() {
    await chrome.storage.local.set({
      [PREPARE_PAGE_SETTINGS_STORAGE_KEY]: {
        cachingTtlSeconds: state.cachingTtlSeconds,
        maxPrepareCredits: state.maxPrepareCredits
      }
    });
  }
  function syncPreparePageSettingsFromUser(user) {
    const cachingTtlSeconds = getCachingTtlSecondsFromUser(user);
    if (cachingTtlSeconds) {
      state.cachingTtlSeconds = cachingTtlSeconds;
      syncCachingTtlInput();
      void savePreparePageSettings().catch((error) => {
        console.error("Failed to persist caching settings from browser profile", error);
      });
    }
  }
  async function saveRegistrationState(browserSessionId, registration) {
    await chrome.storage.local.set({
      [REGISTRATION_STORAGE_KEY]: {
        browserSessionId,
        ...registration
      }
    });
  }
  async function savePreferredVoicePreference() {
    if (!state.browserSessionId) {
      return;
    }
    await saveRegistrationState(state.browserSessionId, {
      assistantSessionId: state.assistantSessionId,
      authToken: state.authToken,
      externalUser: state.currentUser,
      externalUserApiKey: state.externalUserApiKey,
      preferredLanguage: getSelectedLanguage(),
      preferredVoiceId: state.preferredVoiceId,
      preferredVoiceName: state.preferredVoiceName
    });
  }
  async function saveCurrentRegistrationState() {
    if (!state.browserSessionId) {
      return;
    }
    await saveRegistrationState(state.browserSessionId, {
      assistantSessionId: state.assistantSessionId,
      authToken: state.authToken,
      externalUser: state.currentUser,
      externalUserApiKey: state.externalUserApiKey,
      preferredLanguage: getSelectedLanguage(),
      preferredVoiceId: state.preferredVoiceId,
      preferredVoiceName: state.preferredVoiceName
    });
  }
  async function loadRegistrationState() {
    if (!state.browserSessionId) {
      state.assistantSessionId = void 0;
      state.authToken = void 0;
      state.currentUser = null;
      state.externalUserApiKey = void 0;
      state.preferredVoiceId = void 0;
      state.preferredVoiceName = void 0;
      state.pageCacheExpired = false;
      state.registrationRequired = true;
      syncRegistrationForm();
      return;
    }
    const registration = await getRegistrationState(state.browserSessionId);
    state.assistantSessionId = registration?.assistantSessionId;
    state.authToken = registration?.authToken;
    state.currentUser = registration?.externalUser ?? null;
    state.externalUserApiKey = registration?.externalUserApiKey;
    state.preferredVoiceId = registration?.preferredVoiceId ?? getPreferredVoiceIdFromUser(registration?.externalUser);
    state.preferredVoiceName = registration?.preferredVoiceName;
    setSelectedLanguage(
      registration?.preferredLanguage ?? getPreferredLanguageFromUser(registration?.externalUser)
    );
    syncPreparePageSettingsFromUser(registration?.externalUser);
    state.pageCacheExpired = false;
    state.registrationRequired = !((state.externalUserApiKey || state.authToken) && state.assistantSessionId);
    syncCreditIssueStateWithBalance();
    syncRegistrationForm();
  }
  function updatePreparePageCreditCapFromInput() {
    const nextValue = normalizePreparePageCreditCap(
      prepareMaxCreditsInput?.value ?? state.maxPrepareCredits
    );
    state.maxPrepareCredits = nextValue;
    syncPreparePageCreditCapInput();
    render();
    void savePreparePageSettings().catch((error) => {
      console.error("Failed to persist prepare page settings", error);
    });
  }
  function updateCachingTtlFromInput() {
    state.cachingTtlSeconds = normalizeCachingTtlSeconds(
      cachingTtlSelect?.value ?? state.cachingTtlSeconds
    );
    syncCachingTtlInput();
    render();
    void savePreparePageSettings().catch((error) => {
      console.error("Failed to persist caching settings", error);
    });
  }
  function applyBrowserSessionPayload(payload) {
    state.assistantSessionId = typeof payload.assistantSessionId === "string" ? payload.assistantSessionId : payload.assistantSessionId === null ? void 0 : state.assistantSessionId;
    state.authToken = typeof payload.authToken === "string" ? payload.authToken : payload.authToken === null ? void 0 : state.authToken;
    state.currentUser = payload.externalUser === void 0 ? state.currentUser : payload.externalUser ?? null;
    state.externalUserApiKey = typeof payload.externalUserApiKey === "string" ? payload.externalUserApiKey : payload.externalUserApiKey === null ? void 0 : state.externalUserApiKey;
    const payloadCreditsRemaining = Number(payload.creditsRemaining);
    if (state.currentUser && Number.isFinite(payloadCreditsRemaining)) {
      state.currentUser = {
        ...state.currentUser,
        generationCredits: Math.max(0, Math.floor(payloadCreditsRemaining))
      };
    }
    state.registrationRequired = Boolean(payload.registrationRequired);
    const preferredLanguage = getPreferredLanguageFromUser(state.currentUser);
    if (preferredLanguage) {
      setSelectedLanguage(preferredLanguage);
    }
    syncPreparePageSettingsFromUser(state.currentUser);
    syncCreditIssueStateWithBalance();
  }
  async function syncBrowserSession() {
    if (!state.browserSessionId) {
      return;
    }
    const payload = await fetchJson("/api/browser-sessions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        assistantSessionId: state.assistantSessionId,
        ...buildSessionCredentialPayload(),
        cachingTtlSeconds: state.cachingTtlSeconds,
        preferredLanguage: getSelectedLanguage(),
        preferredVoiceId: getSelectedVoiceId()
      })
    });
    applyBrowserSessionPayload(payload);
    await saveCurrentRegistrationState();
    render();
  }
  async function refreshCreditsAfterRequest() {
    if (!state.serverOnline || state.registrationRequired || !state.browserSessionId) {
      return;
    }
    await syncBrowserSession();
  }
  async function submitAccountProfile() {
    if (!state.browserSessionId) {
      return;
    }
    const isRegistrationFlow = state.registrationRequired;
    const endpoint = isRegistrationFlow ? "/api/browser-sessions/register" : "/api/browser-sessions/profile";
    state.registrationSubmitting = true;
    render();
    try {
      const payload = await fetchJson(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          assistantSessionId: state.assistantSessionId,
          ...buildSessionCredentialPayload(),
          cachingTtlSeconds: state.cachingTtlSeconds,
          displayName: registrationDisplayNameNode?.value ?? "",
          email: registrationEmailNode?.value ?? "",
          username: registrationUsernameNode?.value ?? "",
          preferredLanguage: getSelectedLanguage(),
          preferredVoiceId: getSelectedVoiceId()
        })
      });
      applyBrowserSessionPayload(payload);
      state.preferredVoiceId = getSelectedVoiceId();
      state.preferredVoiceName = getSelectedVoiceName();
      state.accountEditorOpen = false;
      await saveRegistrationState(state.browserSessionId, {
        assistantSessionId: state.assistantSessionId,
        authToken: state.authToken,
        externalUser: state.currentUser,
        externalUserApiKey: state.externalUserApiKey,
        preferredLanguage: getSelectedLanguage(),
        preferredVoiceId: state.preferredVoiceId,
        preferredVoiceName: state.preferredVoiceName
      });
      appendLog(
        "system",
        isRegistrationFlow ? payload.starterCreditsGranted && payload.starterCreditsGranted > 0 ? `Registration completed. ${formatCreditsLabel(payload.starterCreditsGranted)} are ready to use.` : "Registration completed. You can now analyze documents and start voice chat." : "Account details updated for this client session."
      );
      await refreshAll();
    } catch (error) {
      console.error("Failed to save Structure Queries account profile", error);
      appendLog(
        "system",
        error instanceof Error ? error.message : isRegistrationFlow ? "Registration failed." : "Failed to update account details."
      );
    } finally {
      state.registrationSubmitting = false;
      render();
    }
  }
  function buildSamsarOneExtensionAuthUrl() {
    const redirectUri = chrome.identity.getRedirectURL("samsar-one");
    const authUrl = new URL("/api/web-auth/extension", `${SERVER_HTTP_ORIGIN}/`);
    authUrl.searchParams.set("redirect_uri", redirectUri);
    authUrl.searchParams.set("source", "structurequeries_extension");
    return authUrl.toString();
  }
  async function launchSamsarOneWebAuthFlow(url) {
    return new Promise((resolve, reject) => {
      chrome.identity.launchWebAuthFlow(
        {
          interactive: true,
          url
        },
        (responseUrl) => {
          const runtimeError = chrome.runtime.lastError;
          if (runtimeError) {
            reject(new Error(runtimeError.message));
            return;
          }
          if (!responseUrl) {
            reject(new Error("Samsar One sign-in was cancelled."));
            return;
          }
          resolve(responseUrl);
        }
      );
    });
  }
  async function resolveSamsarOneSessionFromRedirect(redirectUrl) {
    const callbackUrl = new URL(redirectUrl);
    const loginToken = readOptionalString(callbackUrl.searchParams.get("loginToken"));
    const authToken = readOptionalString(callbackUrl.searchParams.get("authToken"));
    if (loginToken) {
      return fetchJson(
        `/api/web-auth/session?loginToken=${encodeURIComponent(loginToken)}`
      );
    }
    if (authToken) {
      return fetchJson("/api/web-auth/session", {
        headers: {
          Authorization: `Bearer ${authToken}`
        }
      });
    }
    throw new Error("Samsar One did not return a login token.");
  }
  async function continueWithSamsarOne() {
    if (!state.browserSessionId) {
      return;
    }
    state.samsarAuthSubmitting = true;
    render();
    try {
      const redirectUrl = await launchSamsarOneWebAuthFlow(
        buildSamsarOneExtensionAuthUrl()
      );
      const sessionPayload = await resolveSamsarOneSessionFromRedirect(redirectUrl);
      const resolvedAuthToken = readOptionalString(sessionPayload.authToken);
      if (!resolvedAuthToken) {
        throw new Error("Samsar One did not return an auth token.");
      }
      state.authToken = resolvedAuthToken;
      const payload = await fetchJson(
        "/api/browser-sessions/register",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            authToken: resolvedAuthToken,
            browserSessionId: state.browserSessionId,
            cachingTtlSeconds: state.cachingTtlSeconds,
            displayName: readOptionalString(sessionPayload.displayName) ?? registrationDisplayNameNode?.value ?? "",
            email: readOptionalString(sessionPayload.email) ?? registrationEmailNode?.value ?? "",
            username: readOptionalString(sessionPayload.username) ?? registrationUsernameNode?.value ?? "",
            preferredLanguage: getSelectedLanguage(),
            preferredVoiceId: getSelectedVoiceId()
          })
        }
      );
      applyBrowserSessionPayload(payload);
      state.preferredVoiceId = getSelectedVoiceId();
      state.preferredVoiceName = getSelectedVoiceName();
      state.accountEditorOpen = false;
      await saveRegistrationState(state.browserSessionId, {
        assistantSessionId: state.assistantSessionId,
        authToken: state.authToken,
        externalUser: state.currentUser,
        externalUserApiKey: state.externalUserApiKey,
        preferredLanguage: getSelectedLanguage(),
        preferredVoiceId: state.preferredVoiceId,
        preferredVoiceName: state.preferredVoiceName
      });
      showNotification("Connected with Samsar One.");
      appendLog(
        "system",
        "Connected with Samsar One. This browser now uses your existing Samsar account and credits."
      );
      await refreshIndexStatus();
    } catch (error) {
      console.error("Failed to connect with Samsar One", error);
      appendLog(
        "system",
        error instanceof Error ? error.message : "Failed to connect with Samsar One."
      );
    } finally {
      state.samsarAuthSubmitting = false;
      render();
    }
  }
  async function openSamsarClientLogin() {
    if (!state.browserSessionId || state.registrationRequired) {
      return;
    }
    state.loginLinkSubmitting = true;
    render();
    try {
      const payload = await fetchJson(
        "/api/browser-sessions/login-link",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            ...buildSessionCredentialPayload()
          })
        }
      );
      if (payload.externalUser !== void 0) {
        state.currentUser = payload.externalUser ?? null;
      }
      await saveRegistrationState(state.browserSessionId, {
        assistantSessionId: state.assistantSessionId,
        authToken: state.authToken,
        externalUser: state.currentUser,
        externalUserApiKey: state.externalUserApiKey,
        preferredLanguage: getSelectedLanguage(),
        preferredVoiceId: state.preferredVoiceId,
        preferredVoiceName: state.preferredVoiceName
      });
      const loginUrl = readOptionalString(payload.loginUrl);
      if (!loginUrl) {
        throw new Error("Samsar login link was not returned.");
      }
      await chrome.tabs.create({
        url: loginUrl
      });
      appendLog(
        "system",
        "Opened Samsar in a new tab so you can recharge credits."
      );
    } catch (error) {
      console.error("Failed to open Samsar client login", error);
      appendLog(
        "system",
        error instanceof Error ? error.message : "Failed to create the Samsar login link."
      );
    } finally {
      state.loginLinkSubmitting = false;
      render();
    }
  }
  async function refreshServerStatus() {
    try {
      const payload = await fetchJson("/api/health");
      state.serverOnline = payload.status === "ok";
    } catch (error) {
      console.error("Failed to reach server", error);
      state.serverOnline = false;
    }
  }
  async function refreshVoices() {
    if (!state.serverOnline) {
      state.voices = [];
      state.voiceWarning = void 0;
      renderVoiceOptions();
      return;
    }
    try {
      const payload = await fetchJson("/api/voices");
      state.voices = payload.voices;
      state.voiceWarning = readOptionalString(payload.warnings?.[0]);
      for (const warning of payload.warnings ?? []) {
        console.warn("Structure Queries voices warning:", warning);
      }
    } catch (error) {
      console.error("Failed to fetch voices", error);
      state.voices = [];
      state.voiceWarning = error instanceof Error ? error.message : "Failed to fetch voices.";
    }
    renderVoiceOptions();
  }
  async function ensureVoicesLoaded(input) {
    if (!state.serverOnline) {
      voicesLoaded = false;
      state.voices = [];
      state.voiceWarning = void 0;
      renderVoiceOptions();
      return;
    }
    if (!input?.force && voicesLoaded) {
      return;
    }
    if (!input?.force && voicesLoadPromise) {
      return voicesLoadPromise;
    }
    voicesLoadPromise = refreshVoices().then(() => {
      voicesLoaded = true;
    }).finally(() => {
      voicesLoadPromise = void 0;
    });
    return voicesLoadPromise;
  }
  function closeWebSocketSession(input) {
    clearResumeConversationTimer();
    clearConversationIdleTimer();
    stopAssistantPlayback();
    stopVoicePreviewPlayback();
    if (activeSocket) {
      activeSocket.close();
    }
    activeSocket = void 0;
    activeSocketPromise = void 0;
    assistantAudioReceivedForTurn = false;
    creditsRefreshPending = false;
    creditsRefreshInFlight = false;
    state.conversationActive = false;
    state.recording = false;
    state.assistantSpeaking = false;
    state.websocketState = "disconnected";
    state.websocketPhase = input?.phase ?? "idle";
    state.websocketDetail = input?.detail ?? "Idle";
    state.pendingAssistantText = void 0;
    state.pendingAssistantLanguage = void 0;
  }
  async function expireCurrentPageCache(input) {
    const pageUrl = state.currentPage?.url;
    const message = readOptionalString(input?.message) ?? EXPIRED_PAGE_CACHE_MESSAGE;
    abortActiveTextRequest();
    clearPrepareStatusPollTimer();
    setCurrentPrepareRequest(null);
    if (state.conversationActive || state.recording || state.assistantSpeaking) {
      await stopPageRecordingCapture();
    }
    closeWebSocketSession({
      phase: "idle",
      detail: "Prepare page"
    });
    clearPendingTextPromptState();
    state.isAnalyzing = false;
    state.analysisReady = false;
    state.currentTemplateId = void 0;
    state.pageCacheExpired = true;
    state.textSubmitting = false;
    if (pageUrl) {
      await clearAnalyzedPage(pageUrl);
      await removePendingPreparePageRequest(pageUrl);
    }
    render();
    if (input?.appendLog) {
      appendLog("system", message);
    }
    if (input?.appendText) {
      appendTextChatMessage("system", message);
      render();
    }
    if (input?.notify) {
      showNotification(message);
    }
  }
  async function refreshIndexStatus() {
    if (!state.currentPage?.url) {
      state.indexChecked = false;
      state.analysisReady = false;
      state.currentTemplateId = void 0;
      state.pageCacheExpired = false;
      return;
    }
    const localAnalysis = await getAnalyzedPageState(state.currentPage.url);
    state.indexChecked = true;
    state.analysisReady = Boolean(localAnalysis?.analyzed);
    state.currentTemplateId = localAnalysis?.templateId ?? void 0;
    if (!state.serverOnline || state.registrationRequired || !state.currentTemplateId) {
      return;
    }
    try {
      const payload = await fetchJson(
        `/api/webpages/status?url=${encodeURIComponent(
          state.currentPage.url
        )}&templateId=${encodeURIComponent(state.currentTemplateId)}`
      );
      if (isExpiredTemplateCode(payload.code) || readOptionalString(payload.status) === "expired") {
        await expireCurrentPageCache();
        return;
      }
      state.analysisReady = Boolean(localAnalysis?.analyzed) && Boolean(payload.analysisAvailable);
      state.currentTemplateId = payload.templateId ?? state.currentTemplateId;
      state.pageCacheExpired = false;
    } catch (error) {
      console.error("Failed to check webpage status", error);
      if (isExpiredTemplateCode(getErrorCode(error)) || getErrorStatus(error) === 410) {
        await expireCurrentPageCache();
        return;
      }
      state.analysisReady = Boolean(localAnalysis?.analyzed);
    }
  }
  async function syncCreditsRemainingFromPrepareRequest(creditsRemaining) {
    const parsedCredits = Number(creditsRemaining);
    if (!state.currentUser || !Number.isFinite(parsedCredits)) {
      return false;
    }
    state.currentUser = {
      ...state.currentUser,
      generationCredits: Math.max(0, Math.floor(parsedCredits))
    };
    syncCreditIssueStateWithBalance();
    await saveCurrentRegistrationState();
    return true;
  }
  function setCurrentPrepareRequest(request) {
    state.currentPrepareRequestId = request?.requestId;
    state.currentPrepareStatus = request?.status;
  }
  async function sendPendingTextPrompt() {
    const prompt = readOptionalString(state.pendingTextPrompt);
    if (!prompt || state.textSubmitting) {
      return;
    }
    if (state.registrationRequired) {
      clearPendingTextPromptState();
      appendTextChatMessage("system", "Finish setup before using text chat.");
      render();
      return;
    }
    if (!state.currentPage?.url) {
      clearPendingTextPromptState();
      appendTextChatMessage("system", "Open a supported page before asking a text question.");
      render();
      return;
    }
    if (!hasActiveSamsarCredentials() || !state.assistantSessionId) {
      clearPendingTextPromptState();
      appendTextChatMessage(
        "system",
        "Registration is incomplete. Register this browser installation again."
      );
      render();
      return;
    }
    if (!state.currentTemplateId) {
      clearPendingTextPromptState();
      appendTextChatMessage(
        "system",
        state.pageCacheExpired ? EXPIRED_PAGE_CACHE_MESSAGE : "No page context is ready yet. Prepare the page and try again."
      );
      render();
      return;
    }
    abortActiveTextRequest();
    const controller = new AbortController();
    activeTextRequestController = controller;
    state.textSubmitting = true;
    render();
    try {
      const payload = await fetchJson(
        "/api/chat-completion",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          signal: controller.signal,
          body: JSON.stringify({
            assistantSessionId: state.assistantSessionId,
            ...buildSessionCredentialPayload(),
            language: getSelectedLanguage(),
            metadata: {
              responseMode: "text"
            },
            messages: buildTextChatMessages(),
            pageTitle: state.currentPage.title,
            pageUrl: state.currentPage.url,
            stream: false,
            templateId: state.currentTemplateId
          })
        }
      );
      clearPendingTextPromptState();
      const assistantText = readOptionalString(payload.response?.text) ?? readOptionalString(payload.completion?.choices?.[0]?.message?.content) ?? "Assistant reply unavailable.";
      const warnings = payload.response?.warnings ?? [];
      appendTextChatMessage("assistant", assistantText, {
        warnings
      });
      await refreshCreditsAfterRequest();
    } catch (error) {
      if (isAbortError(error)) {
        return;
      }
      const message = error instanceof Error ? error.message : "Failed to generate a grounded text reply.";
      clearPendingTextPromptState();
      if (isInsufficientCreditsMessage(message)) {
        showInsufficientCreditsState(message);
        return;
      }
      if (isExpiredTemplateCode(getErrorCode(error)) || getErrorStatus(error) === 410) {
        await expireCurrentPageCache({
          appendText: true,
          message
        });
        return;
      }
      appendTextChatMessage("system", message);
    } finally {
      if (activeTextRequestController === controller) {
        activeTextRequestController = void 0;
      }
      state.textSubmitting = false;
      render();
    }
  }
  async function submitTextPrompt() {
    const prompt = readOptionalString(state.textDraft);
    if (!prompt || state.textSubmitting || state.isAnalyzing) {
      return;
    }
    if (state.registrationRequired) {
      appendTextChatMessage("system", "Finish setup before using text chat.");
      render();
      return;
    }
    const analyzeUrlError = getAnalyzeUrlError(state.currentPage?.url);
    if (analyzeUrlError) {
      appendTextChatMessage("system", analyzeUrlError);
      render();
      return;
    }
    const messageId = appendTextChatMessage("user", prompt, {
      pending: true
    });
    state.textDraft = "";
    state.pendingTextPrompt = prompt;
    state.pendingTextMessageId = messageId;
    render();
    if (state.pageCacheExpired && !state.analysisReady) {
      clearPendingTextPromptState();
      appendTextChatMessage("system", EXPIRED_PAGE_CACHE_MESSAGE);
      render();
      return;
    }
    if (!state.analysisReady || !state.currentTemplateId) {
      await analyzeCurrentPage({
        connectSocket: false
      });
      return;
    }
    await sendPendingTextPrompt();
  }
  async function finalizePreparedPage(input) {
    clearPrepareStatusPollTimer();
    setCurrentPrepareRequest(null);
    state.isAnalyzing = false;
    state.analysisReady = true;
    state.pageCacheExpired = false;
    state.currentTemplateId = input.templateId ?? state.currentTemplateId;
    await markPageAnalyzed(input.url, {
      analyzed: true,
      templateId: state.currentTemplateId
    });
    await removePendingPreparePageRequest(input.url, input.requestId);
    const creditsPersisted = await syncCreditsRemainingFromPrepareRequest(
      input.creditsRemaining
    );
    if (!creditsPersisted) {
      await refreshCreditsAfterRequest();
    }
    render();
    if (input.logMessage) {
      appendLog("system", input.logMessage);
    }
    if (input.connectSocket) {
      void ensureWebSocketSession().catch((error) => {
        console.error("Failed to prime websocket session after prepare-page", error);
      });
    }
    if (state.pendingTextPrompt) {
      void sendPendingTextPrompt();
    }
  }
  async function failPreparedPage(input) {
    clearPrepareStatusPollTimer();
    setCurrentPrepareRequest(null);
    state.isAnalyzing = false;
    await removePendingPreparePageRequest(input.url, input.requestId);
    const message = readOptionalString(input.message) ?? "Failed to prepare this page.";
    if (input.code === "insufficient_credits" || isInsufficientCreditsMessage(message)) {
      showInsufficientCreditsState(message);
      return;
    }
    if (isExpiredTemplateCode(input.code)) {
      await expireCurrentPageCache({
        appendLog: true,
        appendText: Boolean(state.pendingTextPrompt || state.interactionMode === "text"),
        message
      });
      return;
    }
    await syncCreditsRemainingFromPrepareRequest(input.creditsRemaining);
    render();
    appendLog("system", message);
    if (state.pendingTextPrompt || state.interactionMode === "text") {
      if (state.pendingTextPrompt) {
        clearPendingTextPromptState();
      }
      appendTextChatMessage("system", message);
      render();
    }
  }
  function schedulePendingPreparePageStatusPoll(delayMs = 2500) {
    clearPrepareStatusPollTimer();
    if (!state.serverOnline || !state.currentPage?.url || !state.currentPrepareRequestId) {
      return;
    }
    prepareStatusPollTimer = window.setTimeout(() => {
      prepareStatusPollTimer = void 0;
      void reconcilePendingPreparePageRequest().catch((error) => {
        console.error("Failed to reconcile pending prepare-page request", error);
      });
    }, delayMs);
  }
  async function reconcilePendingPreparePageRequest(pendingRequest) {
    const currentPageUrl = state.currentPage?.url;
    if (!currentPageUrl) {
      clearPrepareStatusPollTimer();
      setCurrentPrepareRequest(null);
      state.isAnalyzing = false;
      return;
    }
    const activeRequest = pendingRequest ?? await getPendingPreparePageRequest(currentPageUrl);
    if (!activeRequest) {
      clearPrepareStatusPollTimer();
      setCurrentPrepareRequest(null);
      state.isAnalyzing = false;
      return;
    }
    if (activeRequest.browserSessionId && state.browserSessionId && activeRequest.browserSessionId !== state.browserSessionId) {
      await removePendingPreparePageRequest(currentPageUrl, activeRequest.requestId);
      clearPrepareStatusPollTimer();
      setCurrentPrepareRequest(null);
      state.isAnalyzing = false;
      return;
    }
    state.isAnalyzing = true;
    setCurrentPrepareRequest(activeRequest);
    render();
    if (!state.serverOnline) {
      return;
    }
    try {
      const query = new URLSearchParams({
        requestId: activeRequest.requestId,
        url: currentPageUrl
      });
      if (activeRequest.templateId) {
        query.set("templateId", activeRequest.templateId);
      }
      const payload = await fetchJson(
        `/api/webpages/status?${query.toString()}`
      );
      const nextTemplateId = payload.templateId ?? activeRequest.templateId;
      const nextStatus = readOptionalString(payload.status) ?? activeRequest.status ?? "pending";
      if (payload.analysisAvailable && nextTemplateId) {
        await finalizePreparedPage({
          url: currentPageUrl,
          requestId: payload.requestId ?? activeRequest.requestId,
          templateId: nextTemplateId,
          creditsRemaining: payload.creditsRemaining,
          logMessage: "Page ready for QA."
        });
        return;
      }
      if (nextStatus === "failed" || nextStatus === "expired" || payload.reason === "prepare_request_failed" || payload.reason === "embedding_template_expired" || payload.code === "insufficient_credits" || isExpiredTemplateCode(payload.code)) {
        await failPreparedPage({
          url: currentPageUrl,
          requestId: activeRequest.requestId,
          message: payload.error,
          code: payload.code,
          creditsRemaining: payload.creditsRemaining
        });
        return;
      }
      const updatedRequest = {
        ...activeRequest,
        requestId: payload.requestId ?? activeRequest.requestId,
        templateId: nextTemplateId,
        status: nextStatus,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      await savePendingPreparePageRequest(currentPageUrl, updatedRequest);
      state.isAnalyzing = true;
      setCurrentPrepareRequest(updatedRequest);
      render();
      schedulePendingPreparePageStatusPoll();
    } catch (error) {
      const status = getErrorStatus(error);
      if (status === 404) {
        await failPreparedPage({
          url: currentPageUrl,
          requestId: activeRequest.requestId,
          message: "The previous prepare-page request could not be resumed. Start it again."
        });
        return;
      }
      console.error("Failed to refresh pending prepare-page request", error);
      state.isAnalyzing = true;
      setCurrentPrepareRequest(activeRequest);
      render();
      schedulePendingPreparePageStatusPoll(4e3);
    }
  }
  async function restorePendingPreparePageRequest() {
    clearPrepareStatusPollTimer();
    setCurrentPrepareRequest(null);
    state.isAnalyzing = false;
    if (!state.currentPage?.url) {
      return;
    }
    const pendingRequest = await getPendingPreparePageRequest(state.currentPage.url);
    if (!pendingRequest) {
      return;
    }
    state.isAnalyzing = true;
    setCurrentPrepareRequest(pendingRequest);
    render();
    await reconcilePendingPreparePageRequest(pendingRequest);
  }
  function sendSocketMessage(message) {
    if (!activeSocket || activeSocket.readyState !== WebSocket.OPEN) {
      return;
    }
    activeSocket.send(JSON.stringify(message));
  }
  function bytesFromBase64(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
  }
  function handleConversationLoopError(error) {
    console.error("Voice chat loop error", error);
    const message = normalizeRecordingError(error);
    if (isInsufficientCreditsMessage(message)) {
      showInsufficientCreditsState(message);
      return;
    }
    closeWebSocketSession({
      phase: "error",
      detail: "Voice chat stopped"
    });
    render();
    appendLog("system", message);
  }
  async function stopConversationMode(input) {
    if (!state.conversationActive && !state.recording && !state.assistantSpeaking) {
      return;
    }
    clearResumeConversationTimer();
    clearConversationIdleTimer();
    state.conversationActive = false;
    state.recording = false;
    state.websocketPhase = "idle";
    state.websocketDetail = input?.detail ?? "Stopped";
    stopAssistantPlayback();
    render();
    try {
      await stopPageRecordingCapture();
    } finally {
      closeWebSocketSession({
        phase: "idle",
        detail: input?.detail ?? "Stopped"
      });
      render();
    }
    if (input?.logMessage) {
      appendLog("system", input.logMessage);
    }
    if (input?.notificationMessage) {
      showNotification(input.notificationMessage);
    }
  }
  async function startConversationTurn() {
    if (!state.conversationActive || state.recording || state.assistantSpeaking) {
      return;
    }
    if (state.registrationRequired) {
      throw new Error("Register this browser installation before starting voice chat.");
    }
    if (await enforceVoiceConversationCreditRequirement({
      stopConversation: true
    })) {
      return;
    }
    state.websocketPhase = "ready";
    state.websocketDetail = "Listening...";
    render();
    await ensureWebSocketSession();
    const response = await sendMessageToClientTab({
      type: "START_PAGE_RECORDING"
    });
    if (!response?.ok) {
      throw new Error(response?.error || "Failed to start microphone recording.");
    }
  }
  function scheduleConversationResume(delayMs = 250) {
    clearResumeConversationTimer();
    if (!state.conversationActive || creditsRefreshInFlight) {
      return;
    }
    resumeConversationTimer = window.setTimeout(() => {
      void startConversationTurn().catch((error) => {
        handleConversationLoopError(error);
      });
    }, delayMs);
  }
  async function playAssistantAudio(audioBase64, mimeType) {
    stopAssistantPlayback();
    stopVoicePreviewPlayback();
    const bytes = bytesFromBase64(audioBase64);
    const blob = new Blob([bytes], {
      type: mimeType
    });
    const objectUrl = URL.createObjectURL(blob);
    const audio = new Audio(objectUrl);
    activeAssistantAudio = audio;
    activeAssistantAudioObjectUrl = objectUrl;
    state.assistantSpeaking = true;
    state.websocketDetail = "Assistant speaking...";
    render();
    return new Promise(async (resolve, reject) => {
      const cleanup = () => {
        if (activeAssistantAudio === audio) {
          activeAssistantAudio = void 0;
        }
        if (activeAssistantAudioObjectUrl === objectUrl) {
          URL.revokeObjectURL(objectUrl);
          activeAssistantAudioObjectUrl = void 0;
        }
        state.assistantSpeaking = false;
        render();
      };
      audio.addEventListener(
        "ended",
        () => {
          cleanup();
          resolve();
        },
        { once: true }
      );
      audio.addEventListener(
        "error",
        () => {
          cleanup();
          reject(new Error("Failed to play assistant audio."));
        },
        { once: true }
      );
      try {
        await audio.play();
      } catch (error) {
        cleanup();
        reject(error);
      }
    });
  }
  function chooseLocalSpeechVoice(language) {
    const availableVoices = window.speechSynthesis.getVoices();
    const preferredLanguage = readOptionalString(language) ?? getSelectedLanguage();
    if (preferredLanguage && preferredLanguage !== "auto") {
      const byLanguage = availableVoices.find(
        (voice) => voice.lang.toLowerCase().startsWith(preferredLanguage.toLowerCase())
      );
      if (byLanguage) {
        return byLanguage;
      }
    }
    return availableVoices[0];
  }
  function speakLocally(text, language) {
    if (!("speechSynthesis" in window) || !text.trim()) {
      return Promise.resolve();
    }
    stopAssistantPlayback();
    stopVoicePreviewPlayback();
    state.assistantSpeaking = true;
    state.websocketDetail = "Assistant speaking...";
    render();
    return new Promise((resolve, reject) => {
      const utterance = new SpeechSynthesisUtterance(text);
      const voice = chooseLocalSpeechVoice(language);
      if (voice) {
        utterance.voice = voice;
      }
      utterance.addEventListener(
        "end",
        () => {
          state.assistantSpeaking = false;
          render();
          resolve();
        },
        { once: true }
      );
      utterance.addEventListener(
        "error",
        () => {
          state.assistantSpeaking = false;
          render();
          reject(new Error("Failed to play local speech."));
        },
        { once: true }
      );
      window.speechSynthesis.speak(utterance);
    });
  }
  function handleSocketMessage(event) {
    const payload = JSON.parse(event.data);
    if (payload.type === "status") {
      const phase = typeof payload.phase === "string" ? payload.phase : "idle";
      const detail = typeof payload.detail === "string" ? payload.detail : "";
      state.websocketPhase = normalizeWebSocketPhase(phase);
      if (!state.assistantSpeaking) {
        state.websocketDetail = detail || phase;
      }
      if (phase === "idle") {
        if (creditsRefreshPending) {
          creditsRefreshPending = false;
          creditsRefreshInFlight = true;
          void refreshCreditsAfterRequest().catch((error) => {
            console.error("Failed to refresh credits after voice turn", error);
          }).finally(() => {
            creditsRefreshInFlight = false;
            if (state.conversationActive && !state.recording && !state.assistantSpeaking && state.websocketPhase === "idle") {
              scheduleConversationResume();
            }
          });
        }
        if (state.pendingAssistantText) {
          const localSpeechText = state.pendingAssistantText;
          const localSpeechLanguage = state.pendingAssistantLanguage;
          state.pendingAssistantText = void 0;
          state.pendingAssistantLanguage = void 0;
          if (state.conversationActive && !assistantAudioReceivedForTurn) {
            void speakLocally(localSpeechText, localSpeechLanguage).catch((error) => {
              console.error("Failed to play local speech", error);
            }).finally(() => {
              scheduleConversationResume();
            });
          }
        } else if (state.conversationActive && !assistantAudioReceivedForTurn) {
          scheduleConversationResume();
        }
      }
      render();
      return;
    }
    if (payload.type === "session_ready") {
      state.websocketState = "ready";
      state.websocketPhase = "ready";
      state.websocketDetail = "Connected";
      state.currentTemplateId = typeof payload.templateId === "string" ? payload.templateId : state.currentTemplateId;
      render();
      return;
    }
    if (payload.type === "voice_updated") {
      const nextVoiceId = readOptionalString(payload.voiceId);
      const matchingVoice = nextVoiceId ? state.voices.find((voice) => voice.voiceId === nextVoiceId) : void 0;
      state.preferredVoiceId = nextVoiceId;
      if (matchingVoice) {
        state.preferredVoiceName = matchingVoice.name;
      }
      if (voiceSelect && Array.from(voiceSelect.options).some(
        (option) => option.value === (nextVoiceId ?? "")
      )) {
        voiceSelect.value = nextVoiceId ?? "";
      }
      renderVoicePreviewButton();
      return;
    }
    if (payload.type === "transcript_ready") {
      const transcript = typeof payload.transcript === "string" ? payload.transcript : "Transcript unavailable.";
      appendLog("user", transcript);
      return;
    }
    if (payload.type === "assistant_message") {
      const text = typeof payload.text === "string" ? payload.text : "Assistant reply unavailable.";
      state.pendingAssistantText = text;
      state.pendingAssistantLanguage = readOptionalString(payload.language);
      appendLog("assistant", text);
      return;
    }
    if (payload.type === "assistant_audio") {
      const audioBase64 = typeof payload.audioBase64 === "string" ? payload.audioBase64 : "";
      const mimeType = typeof payload.mimeType === "string" ? payload.mimeType : "audio/mpeg";
      if (!audioBase64) {
        console.warn("Assistant audio event did not include audio data.");
        return;
      }
      const fallbackText = state.pendingAssistantText;
      const fallbackLanguage = readOptionalString(payload.language) ?? state.pendingAssistantLanguage;
      state.pendingAssistantText = void 0;
      state.pendingAssistantLanguage = void 0;
      assistantAudioReceivedForTurn = true;
      if (audioBase64 && state.conversationActive) {
        void playAssistantAudio(audioBase64, mimeType).catch((error) => {
          console.error("Failed to play assistant audio", error);
          if (fallbackText && state.conversationActive) {
            return speakLocally(fallbackText, fallbackLanguage);
          }
          return Promise.resolve();
        }).finally(() => {
          scheduleConversationResume();
        });
      }
      return;
    }
    if (payload.type === "assistant_image") {
      const imageBase64 = typeof payload.imageBase64 === "string" ? payload.imageBase64 : "";
      const imageUrl = typeof payload.imageUrl === "string" ? payload.imageUrl : "";
      const mimeType = typeof payload.mimeType === "string" ? payload.mimeType : "image/png";
      if (imageBase64 || imageUrl) {
        appendImageLog(
          "assistant",
          {
            imageBase64: imageBase64 || void 0,
            imageUrl: imageUrl || void 0,
            mimeType
          },
          "Image response"
        );
      }
      return;
    }
    if (payload.type === "error") {
      const message = typeof payload.message === "string" ? payload.message : "Unexpected websocket error.";
      const code = typeof payload.code === "string" ? payload.code : void 0;
      if (code === "insufficient_credits" || isInsufficientCreditsMessage(message)) {
        showInsufficientCreditsState(message);
        return;
      }
      if (isExpiredTemplateCode(code)) {
        void expireCurrentPageCache({
          appendLog: true,
          appendText: state.interactionMode === "text",
          message,
          notify: true
        });
        return;
      }
      state.websocketPhase = "error";
      state.websocketDetail = message;
      appendLog("system", message);
      if (state.conversationActive) {
        scheduleConversationResume(600);
      }
      render();
    }
  }
  async function ensureWebSocketSession() {
    if (activeSocket && activeSocket.readyState === WebSocket.OPEN) {
      return activeSocket;
    }
    if (activeSocketPromise) {
      return activeSocketPromise;
    }
    if (!state.browserSessionId || !state.currentPage?.url) {
      throw new Error("Browser session and active page are required.");
    }
    if (state.registrationRequired) {
      throw new Error("Register this browser installation before starting voice chat.");
    }
    if (!hasActiveSamsarCredentials() || !state.assistantSessionId) {
      throw new Error("Registration is incomplete. Register this browser installation again.");
    }
    state.websocketState = "connecting";
    state.websocketPhase = "connected";
    state.websocketDetail = "Connecting...";
    render();
    activeSocketPromise = new Promise((resolve, reject) => {
      const socket = new WebSocket(SERVER_WS_URL);
      socket.addEventListener("message", handleSocketMessage);
      socket.addEventListener("close", () => {
        if (activeSocket === socket) {
          activeSocket = void 0;
          clearConversationIdleTimer();
          state.conversationActive = false;
          state.recording = false;
          state.assistantSpeaking = false;
          state.pendingAssistantText = void 0;
          state.pendingAssistantLanguage = void 0;
          state.websocketState = "disconnected";
          state.websocketPhase = "idle";
          state.websocketDetail = "Disconnected";
          render();
        }
      });
      socket.addEventListener("error", () => {
        reject(new Error("Failed to connect to websocket gateway."));
      });
      socket.addEventListener("open", () => {
        activeSocket = socket;
        state.websocketState = "ready";
        state.websocketPhase = "connected";
        state.websocketDetail = "Connected";
        render();
        sendSocketMessage({
          type: "session_init",
          assistantSessionId: state.assistantSessionId,
          ...buildSessionCredentialPayload(),
          pageUrl: state.currentPage?.url,
          templateId: state.currentTemplateId,
          voiceId: getSelectedVoiceId(),
          language: getSelectedLanguage()
        });
        resolve(socket);
      });
    }).finally(() => {
      activeSocketPromise = void 0;
    });
    return activeSocketPromise;
  }
  async function submitRecordedAudioBase64(audioBase64, mimeType, durationMs) {
    const socket = await ensureWebSocketSession();
    if (socket.readyState !== WebSocket.OPEN) {
      throw new Error("Voice session is not connected.");
    }
    assistantAudioReceivedForTurn = false;
    state.recording = false;
    state.websocketPhase = "transcribing";
    state.websocketDetail = "Processing audio...";
    creditsRefreshPending = true;
    render();
    sendSocketMessage({
      type: "submit_audio",
      audioBase64,
      durationMs,
      mimeType,
      language: getSelectedLanguage(),
      templateId: state.currentTemplateId
    });
  }
  function normalizeRecordingError(error) {
    if (error instanceof DOMException) {
      if (error.name === "NotAllowedError") {
        return "Microphone access was blocked or dismissed. Allow it for this page, then try Start voice again.";
      }
      if (error.name === "NotFoundError") {
        return "No microphone was found on this device.";
      }
      if (error.name === "NotReadableError") {
        return "The microphone is already in use by another app or could not be opened.";
      }
    }
    if (error instanceof Error && error.message.trim()) {
      return error.message;
    }
    return "Failed to start recording.";
  }
  async function getMicrophonePermissionState() {
    if (!navigator.permissions?.query) {
      return void 0;
    }
    try {
      const permissionStatus = await navigator.permissions.query({
        name: "microphone"
      });
      return permissionStatus.state;
    } catch {
      return void 0;
    }
  }
  async function requestMicrophonePermissionFromPanel() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true
      });
      for (const track of stream.getTracks()) {
        track.stop();
      }
    } catch (error) {
      if (error instanceof DOMException && error.name === "NotAllowedError") {
        const permissionState = await getMicrophonePermissionState();
        if (permissionState === "denied") {
          throw new Error(
            "Chrome is currently blocking microphone access for this extension. Open the extension site settings, allow Microphone, then click Start voice again."
          );
        }
      }
      throw error;
    }
  }
  async function startRecording() {
    if (state.conversationActive) {
      return;
    }
    if (state.registrationRequired) {
      throw new Error("Register this browser installation before starting voice chat.");
    }
    if (await enforceVoiceConversationCreditRequirement()) {
      return;
    }
    stopVoicePreviewPlayback();
    hideNotification();
    state.conversationActive = true;
    state.websocketPhase = "connected";
    state.websocketDetail = "Starting...";
    render();
    try {
      await startConversationTurn();
      resetConversationIdleTimer();
    } catch (error) {
      clearConversationIdleTimer();
      state.conversationActive = false;
      try {
        await requestMicrophonePermissionFromPanel();
      } catch {
      }
      throw error;
    }
  }
  async function stopRecording() {
    await stopConversationMode({
      detail: "Stopped"
    });
  }
  async function analyzeCurrentPage(input) {
    if (!state.browserSessionId || !state.currentPage?.url) {
      return;
    }
    state.pageCacheExpired = false;
    updatePreparePageCreditCapFromInput();
    updateCachingTtlFromInput();
    const analyzeUrlError = getAnalyzeUrlError(state.currentPage.url);
    if (state.registrationRequired) {
      appendLog(
        "system",
        "Registration is required before document analysis can start."
      );
      return;
    }
    if (analyzeUrlError) {
      appendLog(
        "system",
        analyzeUrlError
      );
      return;
    }
    const requestId = crypto.randomUUID();
    const pendingRequest = {
      requestId,
      browserSessionId: state.browserSessionId,
      url: state.currentPage.url,
      title: state.currentPage.title,
      status: "crawling",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await savePendingPreparePageRequest(state.currentPage.url, pendingRequest);
    clearPrepareStatusPollTimer();
    setCurrentPrepareRequest(pendingRequest);
    state.isAnalyzing = true;
    render();
    const controller = new AbortController();
    activeAnalyzeRequestController = controller;
    try {
      const payload = await fetchJson("/api/webpages/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        signal: controller.signal,
        body: JSON.stringify({
          ...buildSessionCredentialPayload(),
          cachingTtlSeconds: state.cachingTtlSeconds,
          prepareRequestId: requestId,
          url: state.currentPage.url,
          maxPrepareCredits: state.maxPrepareCredits
        })
      });
      const persistedRequestId = payload.prepareRequestId ?? requestId;
      const templateId = typeof payload.analysis?.templateId === "string" ? payload.analysis.templateId : pendingRequest.templateId;
      const prepareStatus = readOptionalString(payload.prepareStatus) ?? readOptionalString(payload.analysis?.status) ?? "pending";
      const nextPendingRequest = {
        ...pendingRequest,
        requestId: persistedRequestId,
        templateId,
        status: prepareStatus,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      const creditsRemaining = Number(payload.analysis?.raw?.creditsRemaining);
      const analysisAvailable = payload.analysisAvailable ?? true;
      if (analysisAvailable && templateId) {
        await finalizePreparedPage({
          url: state.currentPage.url,
          requestId: persistedRequestId,
          templateId,
          creditsRemaining: Number.isFinite(creditsRemaining) ? creditsRemaining : null,
          connectSocket: input?.connectSocket ?? state.interactionMode === "voice",
          logMessage: "Page ready for QA."
        });
        return;
      }
      await savePendingPreparePageRequest(state.currentPage.url, nextPendingRequest);
      state.isAnalyzing = true;
      setCurrentPrepareRequest(nextPendingRequest);
      render();
      schedulePendingPreparePageStatusPoll();
    } catch (error) {
      if (isAbortError(error)) {
        state.isAnalyzing = true;
        setCurrentPrepareRequest(pendingRequest);
        schedulePendingPreparePageStatusPoll();
        return;
      }
      console.error("Failed to analyze document", error);
      const message = error instanceof Error ? error.message : "Failed to analyze document.";
      const code = getErrorCode(error);
      await failPreparedPage({
        url: state.currentPage.url,
        requestId,
        message,
        code
      });
    } finally {
      if (activeAnalyzeRequestController === controller) {
        activeAnalyzeRequestController = void 0;
      }
      render();
    }
  }
  async function refreshAll() {
    const previousPageUrl = state.currentPage?.url;
    try {
      const extensionSession = await getExtensionSession();
      state.browserSessionId = extensionSession.browserSessionId;
      state.hostTabId = typeof extensionSession.tabId === "number" ? extensionSession.tabId : state.hostTabId;
      await loadPreparePageSettings();
      await loadRegistrationState();
      await refreshServerStatus();
      state.currentPage = await fetchPageContext();
      if (previousPageUrl && previousPageUrl !== state.currentPage?.url) {
        resetTextConversation();
        if (state.conversationActive || state.recording || state.assistantSpeaking) {
          await stopRecording();
        } else {
          closeWebSocketSession();
        }
        resetConversationLog();
        state.currentTemplateId = void 0;
        state.pageCacheExpired = false;
      }
      if (state.serverOnline && state.registrationRequired) {
        await ensureVoicesLoaded();
      }
      await refreshIndexStatus();
      await restorePendingPreparePageRequest();
    } catch (error) {
      console.error("Failed to refresh popup state", error);
    } finally {
      state.isInitializing = false;
      render();
    }
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "OFFSCREEN_RECORDING_STARTED" || message?.type === "PAGE_RECORDING_STARTED") {
      state.recording = true;
      state.websocketPhase = "ready";
      state.websocketDetail = "Listening...";
      resetConversationIdleTimer();
      render();
      return false;
    }
    if (message?.type === "PAGE_RECORDING_STOPPED") {
      state.recording = false;
      state.websocketPhase = "transcribing";
      state.websocketDetail = "Processing audio...";
      render();
      return false;
    }
    if (message?.type === "OFFSCREEN_AUDIO_READY" || message?.type === "PAGE_AUDIO_READY") {
      resetConversationIdleTimer();
      void submitRecordedAudioBase64(
        typeof message.audioBase64 === "string" ? message.audioBase64 : "",
        typeof message.mimeType === "string" ? message.mimeType : "audio/webm",
        typeof message.durationMs === "number" ? message.durationMs : void 0
      ).catch((error) => {
        console.error("Failed to submit recorded audio", error);
        const message2 = error instanceof Error ? error.message : "Failed to submit recorded audio.";
        if (isInsufficientCreditsMessage(message2)) {
          showInsufficientCreditsState(message2);
          return;
        }
        appendLog("system", message2);
      });
      return false;
    }
    if (message?.type === "PAGE_RECORDING_CANCELLED") {
      state.recording = false;
      state.websocketPhase = state.conversationActive ? "ready" : "idle";
      state.websocketDetail = state.conversationActive ? "Listening..." : "Idle";
      render();
      if (state.conversationActive) {
        scheduleConversationResume(100);
      }
      return false;
    }
    if (message?.type === "OFFSCREEN_RECORDING_ERROR" || message?.type === "PAGE_RECORDING_ERROR") {
      state.recording = false;
      clearConversationIdleTimer();
      state.conversationActive = false;
      state.websocketPhase = "error";
      state.websocketDetail = "Microphone unavailable";
      render();
      appendLog(
        "system",
        typeof message.message === "string" ? message.message : "Failed to start recording."
      );
      return false;
    }
    return false;
  });
  accountButton?.addEventListener("click", () => {
    openAccountEditor();
  });
  analyzeButton?.addEventListener("click", () => {
    void analyzeCurrentPage();
  });
  textAnalyzeButton?.addEventListener("click", () => {
    void analyzeCurrentPage({
      connectSocket: false
    });
  });
  registrationFormNode?.addEventListener("submit", (event) => {
    event.preventDefault();
    void submitAccountProfile();
  });
  registrationCloseButton?.addEventListener("click", () => {
    closeAccountEditor();
  });
  registrationOverlayNode?.addEventListener("click", (event) => {
    if (event.target === registrationOverlayNode) {
      closeAccountEditor();
    }
  });
  samsarLoginButton?.addEventListener("click", () => {
    void openSamsarClientLogin();
  });
  samsarAuthButton?.addEventListener("click", () => {
    void continueWithSamsarOne();
  });
  creditWarningButton?.addEventListener("click", () => {
    void openSamsarClientLogin();
  });
  notificationActionButton?.addEventListener("click", () => {
    if (state.notificationAction === "recharge") {
      void openSamsarClientLogin();
    }
  });
  creditWarningDismissButton?.addEventListener("pointerdown", dismissCreditBanner);
  creditWarningDismissButton?.addEventListener("click", dismissCreditBanner);
  voiceToggleButton?.addEventListener("click", () => {
    if (state.conversationActive || state.recording || state.assistantSpeaking) {
      void stopRecording();
      return;
    }
    void startRecording().catch((error) => {
      console.error("Failed to start recording", error);
      appendLog(
        "system",
        normalizeRecordingError(error)
      );
    });
  });
  interactionModeVoiceButton?.addEventListener("click", () => {
    void setInteractionMode("voice");
  });
  interactionModeTextButton?.addEventListener("click", () => {
    void setInteractionMode("text");
  });
  textChatFormNode?.addEventListener("submit", (event) => {
    event.preventDefault();
    void submitTextPrompt();
  });
  textChatThreadNode?.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) {
      return;
    }
    const copyButton = target.closest("[data-text-chat-copy-id]");
    if (!copyButton) {
      return;
    }
    event.preventDefault();
    void copyTextChatMessage(copyButton.dataset.textChatCopyId);
  });
  textChatInputNode?.addEventListener("input", () => {
    state.textDraft = textChatInputNode.value;
    render();
  });
  textChatInputNode?.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void submitTextPrompt();
    }
  });
  voicePreviewButton?.addEventListener("click", () => {
    void ensureVoicesLoaded().then(() => toggleVoicePreviewPlayback()).catch((error) => {
      console.error("Failed to play speaker preview", error);
      appendLog(
        "system",
        error instanceof Error ? error.message : "Failed to play speaker preview."
      );
    });
  });
  voiceSelect?.addEventListener("change", () => {
    state.preferredVoiceId = getSelectedVoiceId();
    state.preferredVoiceName = getSelectedVoiceName();
    stopVoicePreviewPlayback();
    renderVoicePreviewButton();
    void savePreferredVoicePreference().catch((error) => {
      console.error("Failed to persist preferred speaker", error);
    });
    if (activeSocket?.readyState === WebSocket.OPEN) {
      sendSocketMessage({
        type: "set_voice",
        voiceId: getSelectedVoiceId()
      });
    }
  });
  overlayCloseButtons.forEach((button) => {
    button.addEventListener("click", () => {
      void requestOverlayClose();
    });
  });
  languageSelect?.addEventListener("change", () => {
    syncLanguagePreferenceToSocket();
    void saveCurrentRegistrationState().catch((error) => {
      console.error("Failed to persist language preference", error);
    });
  });
  prepareMaxCreditsInput?.addEventListener("change", () => {
    updatePreparePageCreditCapFromInput();
  });
  prepareMaxCreditsInput?.addEventListener("blur", () => {
    updatePreparePageCreditCapFromInput();
  });
  cachingTtlSelect?.addEventListener("change", () => {
    updateCachingTtlFromInput();
  });
  window.addEventListener("pagehide", () => {
    clearPrepareStatusPollTimer();
    abortActiveAnalyzeRequest();
    abortActiveTextRequest();
    stopVoicePreviewPlayback();
    void stopRecording();
  });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState !== "hidden") {
      return;
    }
    void stopConversationMode({
      detail: "Stopped",
      logMessage: "Voice stopped when you left this tab."
    });
  });
  window.addEventListener("focus", () => {
    if (state.creditIssueMessage && state.serverOnline && !state.registrationRequired) {
      void syncBrowserSession().catch((error) => {
        console.error("Failed to refresh browser session after recharge", error);
      });
    }
  });
  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      if (state.accountEditorOpen && !state.registrationRequired) {
        closeAccountEditor();
        return;
      }
      void requestOverlayClose();
    }
  });
  resetConversationLog();
  void refreshAll();
})();
